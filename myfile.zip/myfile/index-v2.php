<input class="hide loc_id_holder" id="to_loc_id" name="to_loc_id" type="hidden" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- فیلدهای تاریخ -->
                                                <div class="col-md-5 nopad secndates">
                                                    <div class="col-xs-6 padfive">
                                                        <div class="lablform">تاریخ رفت</div>
                                                        <div class="plcetogo datemark sidebord datepicker_new1">
                                                            <input type="text" readonly class="normalinput auto-focus hand-cursor form-control b-r-0" id="flight_datepicker1" placeholder="انتخاب تاریخ" value="" name="departure" required/>
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6 padfive date-wrapper">
                                                        <div class="lablform">تاریخ برگشت</div>
                                                        <div class="plcetogo datemark sidebord datepicker_new2">
                                                            <input type="text" readonly class="normalinput auto-focus hand-cursor form-control b-r-0" id="flight_datepicker2" name="return" placeholder="انتخاب تاریخ" value="" disabled="disabled" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- انتخاب مسافران -->
                                            <div class="col-md-4 col-xs-12 nopad thrdtraveller">
                                                <div class="col-xs-7 padfive mobile_width">
                                                    <div class="lablform">&nbsp;</div>
                                                    <div class="totlall">
                                                        <span class="remngwd">
                                                            <span class="total_pax_count">1</span> 
                                                            <span id="travel_text">مسافر</span>
                                                        </span>
                                                        <div class="roomcount pax_count_div">
                                                            <div class="inallsn">
                                                                <div class="oneroom fltravlr">
                                                                    <div class="lablform2">مسافران</div>
                                                                    
                                                                    <!-- بزرگسالان -->
                                                                    <div class="roomrow">
                                                                        <div class="celroe col-xs-7">
                                                                            <i class="fas fa-male"></i> بزرگسالان
                                                                            <span class="agemns">(12+)</span>
                                                                        </div>
                                                                        <div class="celroe col-xs-5">
                                                                            <div class="input-group countmore pax-count-wrapper adult_count_div">
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="minus" data-field="adult">
                                                                                        <span class="fa fa-minus"></span>
                                                                                    </button>
                                                                                </span>
                                                                                <input type="text" id="OWT_adult" name="adult" class="form-control input-number centertext valid_class pax_count_value" value="1" min="1" max="9" readonly>
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="adult">
                                                                                        <span class="fa fa-plus"></span>
                                                                                    </button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <!-- کودکان -->
                                                                    <div class="roomrow">
                                                                        <div class="celroe col-xs-7">
                                                                            <i class="fas fa-child"></i> کودکان
                                                                            <span class="agemns">(2-11)</span>
                                                                        </div>
                                                                        <div class="celroe col-xs-5">
                                                                            <div class="input-group countmore pax-count-wrapper child_count_div">
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="minus" data-field="child">
                                                                                        <span class="fa fa-minus"></span>
                                                                                    </button>
                                                                                </span>
                                                                                <input type="text" id="OWT_child" name="child" class="form-control input-number centertext pax_count_value" value="0" min="0" max="9" readonly>
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="child">
                                                                                        <span class="fa fa-plus"></span>
                                                                                    </button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <!-- نوزادان -->
                                                                    <div class="roomrow last">
                                                                        <div class="celroe col-xs-7">
                                                                            <i class="fas fa-baby"></i> نوزادان
                                                                            <span class="agemns">(0-2)</span>
                                                                        </div>
                                                                        <div class="celroe col-xs-5">
                                                                            <div class="input-group countmore pax-count-wrapper infant_count_div">
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="minus" data-field="infant">
                                                                                        <span class="fa fa-minus"></span>
                                                                                    </button>
                                                                                </span>
                                                                                <input type="text" id="OWT_infant" name="infant" class="form-control input-number centertext pax_count_value" value="0" min="0" max="9" readonly>
                                                                                <span class="input-group-btn">
                                                                                    <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="infant">
                                                                                        <span class="fa fa-plus"></span>
                                                                                    </button>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <a class="done1 comnbtn_room1 btn btn-primary">
                                                                        <span class="fa fa-check"></span> تأیید
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- دکمه جستجو -->
                                                <div class="col-xs-5 padfive mobile_width">
                                                    <div class="lablform">&nbsp;</div>
                                                    <div class="searchsbmtfot">
                                                        <input type="submit" name="search_flight" id="flight-form-submit" class="searchsbmt flight_search_btn" value="جستجو" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- تب هتل -->
                            <div class="tab-pane" id="hotel">
                                <form name="hotel_search" id="hotel_search" autocomplete="on" action="<?php echo esc_url(home_url('/hotel-search')); ?>">
                                    <div class="tabspl forhotelonly">
                                        <div class="tabrow">
                                            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-5 padfive full_clear">
                                                <div class="lablform">مقصد</div>
                                                <div class="plcetogo plcemark sidebord">
                                                    <input type="text" id="hotel_destination_search_name" class="hotel_city normalinput form-control b-r-0" placeholder="شهر، منطقه یا نام هتل" name="city" required value=""/>
                                                    <input class="hide loc_id_holder" name="hotel_destination" type="hidden" value="" >
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-5 padfive">
                                                <div class="lablform">تاریخ ورود</div>
                                                <div class="plcetogo datemark sidebord">
                                                    <input type="text" readonly class="normalinput auto-focus hand-cursor form-control b-r-0" id="hotel_checkin" placeholder="انتخاب تاریخ" name="checkin" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-5 padfive">
                                                <div class="lablform">تاریخ خروج</div>
                                                <div class="plcetogo datemark sidebord">
                                                    <input type="text" readonly class="normalinput auto-focus hand-cursor form-control b-r-0" id="hotel_checkout" placeholder="انتخاب تاریخ" name="checkout" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-2 col-md-3 col-sm-6 col-xs-5 padfive">
                                                <div class="lablform">اتاق و مسافر</div>
                                                <div class="totlall">
                                                    <span class="remngwd">1 اتاق، 1 مسافر</span>
                                                </div>
                                            </div>
                                            
                                            <div class="col-xs-5 padfive mobile_width">
                                                <div class="lablform">&nbsp;</div>
                                                <div class="searchsbmtfot">
                                                    <input type="submit" name="search_hotel" class="searchsbmt" value="جستجو" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- تب تور -->
                            <div class="tab-pane" id="tour">
                                <form name="tour_search" id="tour_search" action="<?php echo esc_url(home_url('/tour-search')); ?>">
                                    <div class="tabspl">
                                        <div class="tabrow">
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">مقصد</div>
                                                <div class="plcetogo plcemark sidebord">
                                                    <input type="text" class="normalinput form-control b-r-0" placeholder="شهر یا کشور مقصد" name="destination" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">تاریخ شروع</div>
                                                <div class="plcetogo datemark sidebord">
                                                    <input type="text" readonly class="normalinput hand-cursor form-control b-r-0" placeholder="انتخاب تاریخ" name="start_date" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2 col-xs-6 padfive">
                                                <div class="lablform">مدت تور</div>
                                                <div class="plcetogo selctmark sidebord">
                                                    <select class="normalsel padselct" name="duration">
                                                        <option value="">انتخاب کنید</option>
                                                        <option value="1-3">1-3 روز</option>
                                                        <option value="4-7">4-7 روز</option>
                                                        <option value="8-15">8-15 روز</option>
                                                        <option value="15+">بیش از 15 روز</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2 col-xs-6 padfive">
                                                <div class="lablform">تعداد نفرات</div>
                                                <div class="totlall">
                                                    <span class="remngwd">1 نفر</span>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2 col-xs-12 padfive">
                                                <div class="lablform">&nbsp;</div>
                                                <div class="searchsbmtfot">
                                                    <input type="submit" name="search_tour" class="searchsbmt" value="جستجو" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- تب اتوبوس -->
                            <div class="tab-pane" id="bus">
                                <form name="bus_search" id="bus_search" action="<?php echo esc_url(home_url('/bus-search')); ?>">
                                    <div class="tabspl">
                                        <div class="tabrow">
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">مبدا</div>
                                                <div class="plcetogo deprtures sidebord">
                                                    <input type="text" class="normalinput form-control b-r-0" placeholder="شهر مبدا" name="from" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">مقصد</div>
                                                <div class="plcetogo destinatios sidebord">
                                                    <input type="text" class="normalinput form-control b-r-0" placeholder="شهر مقصد" name="to" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">تاریخ حرکت</div>
                                                <div class="plcetogo datemark sidebord">
                                                    <input type="text" readonly class="normalinput hand-cursor form-control b-r-0" placeholder="انتخاب تاریخ" name="departure_date" required/>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3 col-xs-6 padfive">
                                                <div class="lablform">&nbsp;</div>
                                                <div class="searchsbmtfot">
                                                    <input type="submit" name="search_bus" class="searchsbmt" value="جستجو" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- محتوای اصلی صفحه -->
    <div class="contentarae">
        
        <!-- بخش پیشنهادات ویژه -->
        <div class="htldeals">
            <div class="container">
                <div class="pagehdwrap">
                    <h2 class="pagehding">پیشنهادات ویژه</h2>
                    <p class="subpagehd">بهترین تخفیف‌ها و پیشنهادات سفر</p>
                    <span>ویژه</span>
                </div>
                
                <div class="tophtls">
                    <div class="row retmnus" id="special-offers">
                        <?php
                        // نمایش پیشنهادات ویژه
                        $special_offers = new WP_Query(array(
                            'post_type' => array('flight', 'hotel', 'tour'),
                            'posts_per_page' => 6,
                            'meta_key' => '_featured',
                            'meta_value' => '1',
                            'orderby' => 'rand'
                        ));
                        
                        if ($special_offers->have_posts()) :
                            while ($special_offers->have_posts()) : $special_offers->the_post();
                        ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="inspd2 effect-lexi">
                                <div class="dealimg">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail('flyairtour-deal'); ?>
                                        </a>
                                    <?php else : ?>
                                        <div class="no-image">
                                            <i class="fas fa-image"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <figcaption>
                                    <div class="deal_txt">
                                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                        <h4>
                                            <?php 
                                            $post_type = get_post_type();
                                            if ($post_type == 'flight') {
                                                $departure = get_post_meta(get_the_ID(), '_flight_departure_city', true);
                                                $arrival = get_post_meta(get_the_ID(), '_flight_arrival_city', true);
                                                echo esc_html($departure . ' - ' . $arrival);
                                            } elseif ($post_type == 'hotel') {
                                                $location = get_post_meta(get_the_ID(), '_hotel_location', true);
                                                echo esc_html($location);
                                            } elseif ($post_type == 'tour') {
                                                $destination = get_post_meta(get_the_ID(), '_tour_destination', true);
                                                echo esc_html($destination);
                                            }
                                            ?>
                                        </h4>
                                        <div class="deal_price">
                                            <?php
                                            $price_field = '_' . $post_type . '_price';
                                            $price = get_post_meta(get_the_ID(), $price_field, true);
                                            if ($price) {
                                                echo flyairtour_format_price($price);
                                            } else {
                                                echo '<span>تماس بگیرید</span>';
                                            }
                                            ?>
                                            <span>شروع از</span>
                                        </div>
                                        <?php if ($post_type == 'hotel') : ?>
                                        <div class="rating-stars">
                                            <?php 
                                            $rating = get_post_meta(get_the_ID(), '_hotel_rating', true);
                                            if ($rating) {
                                                echo flyairtour_star_rating($rating);
                                            }
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </figcaption>
                            </div>
                        </div>
                        <?php 
                            endwhile;
                            wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- بخش مقاصد محبوب -->
        <div class="perhldys">
            <div class="container">
                <div class="pagehdwrap">
                    <h2 class="pagehding leftpgr">مقاصد محبوب</h2>
                    <p>کشف مقاصد زیبا و دیدنی</p>
                    <span>مقاصد</span>
                </div>
                
                <div class="row retmnus">
                    <?php
                    // نمایش مقاصد محبوب
                    $destinations = get_terms(array(
                        'taxonomy' => 'destination',
                        'hide_empty' => false,
                        'number' => 8,
                        'meta_key' => 'featured',
                        'meta_value' => '1'
                    ));
                    
                    if (!empty($destinations) && !is_wp_error($destinations)) :
                        foreach ($destinations as $destination) :
                            $image = get_term_meta($destination->term_id, 'image', true);
                    ?>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="inspd">
                            <div class="imgeht">
                                <?php if ($image) : ?>
                                    <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($destination->name); ?>">
                                <?php else : ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/images/default-destination.jpg" alt="<?php echo esc_attr($destination->name); ?>">
                                <?php endif; ?>
                                <div class="absint">
                                    <div class="absinn">
                                        <h3><?php echo esc_html($destination->name); ?></h3>
                                        <p><?php echo esc_html($destination->description); ?></p>
                                        <a href="<?php echo get_term_link($destination); ?>" class="btn btn-primary">مشاهده تورها</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        endforeach;
                    endif;
                    ?>
                </div>
            </div>
        </div>

        <!-- بخش خدمات -->
        <div class="htldeals">
            <div class="container">
                <div class="pagehdwrap">
                    <h2 class="pagehding">چرا فلای ایر تور؟</h2>
                    <p class="subpagehd">مزایای انتخاب ما برای سفر شما</p>
                    <span>خدمات</span>
                </div>
                
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item text-center">
                            <div class="service-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <h4>پرداخت امن</h4>
                            <p>تمامی پرداخت‌ها با استفاده از درگاه‌های معتبر و امن انجام می‌شود</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item text-center">
                            <div class="service-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <h4>پشتیبانی 24/7</h4>
                            <p>تیم پشتیبانی ما 24 ساعته آماده پاسخگویی به سوالات شماست</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item text-center">
                            <div class="service-icon">
                                <i class="fas fa-tags"></i>
                            </div>
                            <h4>بهترین قیمت</h4>
                            <p>تضمین بهترین قیمت در بازار با امکان مقایسه قیمت</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="service-item text-center">
                            <div class="service-icon">
                                <i class="fas fa-undo"></i>
                            </div>
                            <h4>لغو رایگان</h4>
                            <p>امکان لغو و تغییر رزرو بدون هزینه اضافی تا 24 ساعت قبل</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- بخش آخرین مقالات -->
        <?php if (have_posts()) : ?>
        <div class="perhldys">
            <div class="container">
                <div class="pagehdwrap">
                    <h2 class="pagehding leftpgr">آخرین اخبار و مقالات</h2>
                    <p>به‌روزترین اطلاعات سفر و گردشگری</p>
                    <span>مقالات</span>
                </div>
                
                <div class="row">
                    <?php 
                    $blog_posts = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => 3,
                        'orderby' => 'date',
                        'order' => 'DESC'
                    ));
                    
                    while ($blog_posts->have_posts()) : $blog_posts->the_post(); 
                    ?>
                    <div class="col-md-4">
                        <article class="blog-post-item">
                            <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('flyairtour-medium'); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                            
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                
                                <div class="post-meta">
                                    <span class="post-date">
                                        <i class="fas fa-calendar-alt"></i>
                                        <?php echo get_the_date(); ?>
                                    </span>
                                    <span class="post-author">
                                        <i class="fas fa-user"></i>
                                        <?php the_author(); ?>
                                    </span>
                                </div>
                                
                                <div class="post-excerpt">
                                    <?php the_excerpt(); ?>
                                </div>
                                
                                <a href="<?php the_permalink(); ?>" class="read-more">
                                    ادامه مطلب <i class="fas fa-arrow-left"></i>
                                </a>
                            </div>
                        </article>
                    </div>
                    <?php 
                    endwhile; 
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<!-- اسکریپت‌های سفارشی -->
<script>
jQuery(document).ready(function($) {
    // تنظیم تاریخ‌پیکر
    $('#flight_datepicker1, #flight_datepicker2, #hotel_checkin, #hotel_checkout').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: 0,
        changeMonth: true,
        changeYear: true
    });

    // فعال/غیرفعال کردن تاریخ برگشت
    $('input[name="trip_type"]').change(function() {
        if ($(this).val() === 'circle') {
            $('#flight_datepicker2').prop('disabled', false);
        } else {
            $('#flight_datepicker2').prop('disabled', true).val('');
        }
    });

    // تعویض مبدا و مقصد
    $('.flight_chnge').click(function() {
        var from = $('#from').val();
        var to = $('#to').val();
        $('#from').val(to);
        $('#to').val(from);
        $(this).find('.fa-exchange-alt').toggleClass('rot_arrow');
    });

    // مدیریت تعداد مسافران
    $('.btn-number').click(function(e) {
        e.preventDefault();
        
        var type = $(this).data('type');
        var field = $(this).data('field');
        var input = $('input[name="' + field + '"]');
        var currentVal = parseInt(input.val());
        
        if (!isNaN(currentVal)) {
            if (type == 'minus') {
                var minValue = parseInt(input.attr('min'));
                if (currentVal > minValue) {
                    input.val(currentVal - 1);
                }
            } else if (type == 'plus') {
                var maxValue = parseInt(input.attr('max'));
                if (currentVal < maxValue) {
                    input.val(currentVal + 1);
                }
            }
        }
        
        updatePassengerCount();
    });

    function updatePassengerCount() {
        var adults = parseInt($('#OWT_adult').val()) || 0;
        var children<?php
/**
 * index.php - صفحه اصلی تم فلای ایر تور
 * مشابه صفحه اصلی Travelomatix
 */

get_header(); ?>

<div class="allpagewrp">
    <!-- منطقه جستجو و hero section -->
    <div class="searcharea">
        <div class="srchinarea">
            <div class="container">
                <div class="captngrp">
                    <div id="big1" class="bigcaption">
                        <?php 
                        $hero_title = get_theme_mod('hero_title', 'سفری فراموش‌نشدنی را تجربه کنید');
                        echo esc_html($hero_title);
                        ?>
                    </div>
                    <div id="desc" class="smalcaptn">
                        <?php 
                        $hero_subtitle = get_theme_mod('hero_subtitle', 'بهترین قیمت‌ها برای پرواز، هتل و تور');
                        echo esc_html($hero_subtitle);
                        ?>
                        <span class="boder"></span>
                    </div>
                </div>
            </div>

            <!-- فرم جستجو -->
            <div class="allformst">
                <div class="container inspad">
                    <div class="secndblak">
                        <div class="tab-content custmtab">
                            
                            <!-- تب پرواز -->
                            <div class="tab-pane active" id="flight">
                                <!-- منوی تب‌ها -->
                                <ul class="nav nav-tabs customtab" role="tablist">
                                    <li class="active">
                                        <a href="#flight" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-plane morefa"></i> پرواز</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#hotel" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-building morefa"></i> هتل</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tour" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-route morefa"></i> تور</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#bus" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-bus morefa"></i> اتوبوس</span>
                                        </a>
                                    </li>
                                </ul>

                                <!-- فرم جستجوی پرواز -->
                                <form autocomplete="off" name="flight" id="flight_form" action="<?php echo esc_url(home_url('/flight-search')); ?>" method="get" class="activeForm oneway_frm">
                                    <div class="tabspl">
                                        <div class="tabrow">
                                            <!-- نوع سفر -->
                                            <div class="waywy">
                                                <div class="smalway">
                                                    <label class="wament hand-cursor active">
                                                        <input class="hide" type="radio" name="trip_type" checked="checked" id="onew-trp" value="oneway" /> 
                                                        یک طرفه
                                                    </label>
                                                    <label class="wament hand-cursor">
                                                        <input class="hide" type="radio" name="trip_type" id="rnd-trp" value="circle" /> 
                                                        رفت و برگشت
                                                    </label>
                                                    <label class="wament hand-cursor">
                                                        <input class="hide" type="radio" name="trip_type" id="multi-trp" value="multicity" /> 
                                                        چند شهره
                                                    </label>
                                                </div>
                                            </div>

                                            <!-- فیلدهای مبدا و مقصد -->
                                            <div id="onw_rndw_fieldset" class="col-md-8 nopad">
                                                <div class="col-md-7 nopad placerows">
                                                    <div class="col-xs-6 padfive">
                                                        <div class="lablform">مبدا</div>
                                                        <div class="plcetogo deprtures sidebord">
                                                            <input type="text" autocomplete="off" name="from" class="normalinput auto-focus valid_class fromflight form-control b-r-0" id="from" placeholder="شهر مبدا" value="" required />
                                                            <input class="hide loc_id_holder" id="from_loc_id" name="from_loc_id" type="hidden" value="" >
                                                            <div class="flight_chnge">
                                                                <i class="fas fa-exchange-alt rot_arrow"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6 padfive">
                                                        <div class="lablform">مقصد</div>
                                                        <div class="plcetogo destinatios sidebord">
                                                            <input type="text" autocomplete="off" name="to" class="normalinput auto-focus valid_class departflight form-control b-r-0" id="to" placeholder="شهر مقصد" value="" required/>
                                                            <input class="hide loc