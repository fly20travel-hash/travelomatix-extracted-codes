<?php
/**
 * functions.php - فایل توابع تم فلای ایر تور
 * مشابه سیستم Travelomatix با قابلیت‌های کامل
 */

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// ثوابت تم
define('FLYAIRTOUR_VERSION', '1.0.0');
define('FLYAIRTOUR_THEME_DIR', get_template_directory());
define('FLYAIRTOUR_THEME_URI', get_template_directory_uri());

/**
 * تنظیمات اولیه تم
 */
function flyairtour_setup() {
    // پشتیبانی از زبان‌های مختلف
    load_theme_textdomain('flyairtour-theme', get_template_directory() . '/languages');

    // پشتیبانی از تصویر شاخص پست
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(300, 200, true);

    // اندازه‌های مختلف تصاویر
    add_image_size('flyairtour-large', 800, 600, true);
    add_image_size('flyairtour-medium', 400, 300, true);
    add_image_size('flyairtour-small', 200, 150, true);
    add_image_size('flyairtour-deal', 350, 250, true);

    // پشتیبانی از RSS
    add_theme_support('automatic-feed-links');

    // پشتیبانی از عنوان صفحه
    add_theme_support('title-tag');

    // پشتیبانی از HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // پشتیبانی از لوگو سفارشی
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // ثبت منوها
    register_nav_menus(array(
        'primary' => esc_html__('منوی اصلی', 'flyairtour-theme'),
        'footer'  => esc_html__('منوی فوتر', 'flyairtour-theme'),
        'mobile'  => esc_html__('منوی موبایل', 'flyairtour-theme'),
    ));

    // پشتیبانی از ویجت‌ها
    add_theme_support('widgets');

    // پشتیبانی از فرمت‌های پست
    add_theme_support('post-formats', array(
        'gallery',
        'image',
        'video',
        'quote',
        'link'
    ));

    // پشتیبانی از Woocommerce
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'flyairtour_setup');

/**
 * تنظیم عرض محتوا
 */
if (!isset($content_width)) {
    $content_width = 1200;
}

/**
 * بارگذاری استایل‌ها و اسکریپت‌ها
 */
function flyairtour_scripts() {
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');

    // Bootstrap CSS
    wp_enqueue_style('bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/3.4.1/css/bootstrap.min.css', array(), '3.4.1');

    // jQuery UI CSS
    wp_enqueue_style('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/themes/ui-lightness/jquery-ui.min.css', array(), '1.13.2');

    // استایل اصلی تم
    wp_enqueue_style('flyairtour-style', get_stylesheet_uri(), array(), FLYAIRTOUR_VERSION);

    // jQuery (از وردپرس)
    wp_enqueue_script('jquery');

    // Bootstrap JS
    wp_enqueue_script('bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/3.4.1/js/bootstrap.min.js', array('jquery'), '3.4.1', true);

    // jQuery UI
    wp_enqueue_script('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js', array('jquery'), '1.13.2', true);

    // Owl Carousel
    wp_enqueue_style('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css', array(), '2.3.4');
    wp_enqueue_style('owl-theme', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css', array(), '2.3.4');
    wp_enqueue_script('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array('jquery'), '2.3.4', true);

    // اسکریپت سفارشی تم
    wp_enqueue_script('flyairtour-custom', get_template_directory_uri() . '/js/custom.js', array('jquery', 'bootstrap', 'jquery-ui'), FLYAIRTOUR_VERSION, true);

    // متغیرهای Ajax
    wp_localize_script('flyairtour-custom', 'flyairtour_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('flyairtour_nonce'),
        'strings'  => array(
            'loading'      => esc_html__('در حال بارگذاری...', 'flyairtour-theme'),
            'error'        => esc_html__('خطا در برقراری ارتباط', 'flyairtour-theme'),
            'search_error' => esc_html__('لطفاً فیلدهای جستجو را کامل کنید', 'flyairtour-theme'),
        )
    ));

    // اسکریپت نظرات
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'flyairtour_scripts');

/**
 * ثبت sidebar ها و ویجت‌ها
 */
function flyairtour_widgets_init() {
    // سایدبار اصلی
    register_sidebar(array(
        'name'          => esc_html__('سایدبار اصلی', 'flyairtour-theme'),
        'id'            => 'main-sidebar',
        'description'   => esc_html__('ویجت‌های سایدبار اصلی', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    // فوتر - ستون 1
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون اول', 'flyairtour-theme'),
        'id'            => 'footer-1',
        'description'   => esc_html__('ویجت‌های ستون اول فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 2
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون دوم', 'flyairtour-theme'),
        'id'            => 'footer-2',
        'description'   => esc_html__('ویجت‌های ستون دوم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 3
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون سوم', 'flyairtour-theme'),
        'id'            => 'footer-3',
        'description'   => esc_html__('ویجت‌های ستون سوم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 4
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون چهارم', 'flyairtour-theme'),
        'id'            => 'footer-4',
        'description'   => esc_html__('ویجت‌های ستون چهارم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'flyairtour_widgets_init');

/**
 * Custom Post Types برای سیستم رزرو
 */

// نوع پست پرواز
function flyairtour_register_flight_post_type() {
    $labels = array(
        'name'               => esc_html__('پروازها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('پرواز', 'flyairtour-theme'),
        'menu_name'          => esc_html__('پروازها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن پرواز جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن پرواز جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('پرواز جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش پرواز', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده پرواز', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه پروازها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی پرواز', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'flights'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-airplane',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest'       => true,
    );

    register_post_type('flight', $args);
}
add_action('init', 'flyairtour_register_flight_post_type');

// نوع پست هتل
function flyairtour_register_hotel_post_type() {
    $labels = array(
        'name'               => esc_html__('هتل‌ها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('هتل', 'flyairtour-theme'),
        'menu_name'          => esc_html__('هتل‌ها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن هتل جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن هتل جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('هتل جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش هتل', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده هتل', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه هتل‌ها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی هتل', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'hotels'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 21,
        'menu_icon'          => 'dashicons-building',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments'),
        'show_in_rest'       => true,
    );

    register_post_type('hotel', $args);
}
add_action('init', 'flyairtour_register_hotel_post_type');

// نوع پست تور
function flyairtour_register_tour_post_type() {
    $labels = array(
        'name'               => esc_html__('تورها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('تور', 'flyairtour-theme'),
        'menu_name'          => esc_html__('تورها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن تور جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن تور جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('تور جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش تور', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده تور', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه تورها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی تور', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'tours'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 22,
        'menu_icon'          => 'dashicons-palmtree',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments'),
        'show_in_rest'       => true,
    );

    register_post_type('tour', $args);
}
add_action('init', 'flyairtour_register_tour_post_type');

/**
 * Custom Taxonomies
 */

// تکسونومی مقاصد
function flyairtour_register_destination_taxonomy() {
    $labels = array(
        'name'              => esc_html__('مقاصد', 'flyairtour-theme'),
        'singular_name'     => esc_html__('مقصد', 'flyairtour-theme'),
        'search_items'      => esc_html__('جستجوی مقصد', 'flyairtour-theme'),
        'all_items'         => esc_html__('همه مقاصد', 'flyairtour-theme'),
        'parent_item'       => esc_html__('مقصد والد', 'flyairtour-theme'),
        'parent_item_colon' => esc_html__('مقصد والد:', 'flyairtour-theme'),
        'edit_item'         => esc_html__('ویرایش مقصد', 'flyairtour-theme'),
        'update_item'       => esc_html__('بروزرسانی مقصد', 'flyairtour-theme'),
        'add_new_item'      => esc_html__('افزودن مقصد جدید', 'flyairtour-theme'),
        'new_item_name'     => esc_html__('نام مقصد جدید', 'flyairtour-theme'),
        'menu_name'         => esc_html__('مقاصد', 'flyairtour-theme'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'destination'),
        'show_in_rest'      => true,
    );

    register_taxonomy('destination', array('flight', 'hotel', 'tour'), $args);
}
add_action('init', 'flyairtour_register_destination_taxonomy');

// تکسونومی شرکت‌های هواپیمایی
function flyairtour_register_airline_taxonomy() {
    $labels = array(
        'name'              => esc_html__('شرکت‌های هواپیمایی', 'flyairtour-theme'),
        'singular_name'     => esc_html__('شرکت هواپیمایی', 'flyairtour-theme'),
        'search_items'      => esc_html__('جستجوی شرکت', 'flyairtour-theme'),
        'all_items'         => esc_html__('همه شرکت‌ها', 'flyairtour-theme'),
        'edit_item'         => esc_html__('ویرایش شرکت', 'flyairtour-theme'),
        'update_item'       => esc_html__('بروزرسانی شرکت', 'flyairtour-theme'),
        'add_new_item'      => esc_html__('افزودن شرکت جدید', 'flyairtour-theme'),
        'new_item_name'     => esc_html__('نام شرکت جدید', 'flyairtour-theme'),
        'menu_name'         => esc_html__('شرکت‌های هواپیمایی', 'flyairtour-theme'),
    );

    $args = array(
        'hierarchical'      => false,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'airline'),
        'show_in_rest'      => true,
    );

    register_taxonomy('airline', array('flight'), $args);
}
add_action('init', 'flyairtour_register_airline_taxonomy');

/**
 * Meta Boxes برای اطلاعات اضافی
 */

// متاباکس اطلاعات پرواز
function flyairtour_add_flight_metabox() {
    add_meta_box(
        'flight-details',
        esc_html__('جزئیات پرواز', 'flyairtour-theme'),
        'flyairtour_flight_metabox_callback',
        'flight',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'flyairtour_add_flight_metabox');

function flyairtour_flight_metabox_callback($post) {
    wp_nonce_field('flyairtour_flight_meta_nonce', 'flyairtour_flight_meta_nonce');
    
    $departure_city = get_post_meta($post->ID, '_flight_departure_city', true);
    $arrival_city = get_post_meta($post->ID, '_flight_arrival_city', true);
    $departure_time = get_post_meta($post->ID, '_flight_departure_time', true);
    $arrival_time = get_post_meta($post->ID, '_flight_arrival_time', true);
    $price = get_post_meta($post->ID, '_flight_price', true);
    $duration = get_post_meta($post->ID, '_flight_duration', true);
    $flight_number = get_post_meta($post->ID, '_flight_number', true);
    ?>
    <table class="form-table">
        <tr>
            <th><label for="flight_departure_city"><?php esc_html_e('شهر مبدا', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_departure_city" name="flight_departure_city" value="<?php echo esc_attr($departure_city); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_arrival_city"><?php esc_html_e('شهر مقصد', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_arrival_city" name="flight_arrival_city" value="<?php echo esc_attr($arrival_city); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_departure_time"><?php esc_html_e('زمان حرکت', 'flyairtour-theme'); ?></label></th>
            <td><input type="datetime-local" id="flight_departure_time" name="flight_departure_time" value="<?php echo esc_attr($departure_time); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_arrival_time"><?php esc_html_e('زمان رسیدن', 'flyairtour-theme'); ?></label></th>
            <td><input type="datetime-local" id="flight_arrival_time" name="flight_arrival_time" value="<?php echo esc_attr($arrival_time); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_price"><?php esc_html_e('قیمت (تومان)', 'flyairtour-theme'); ?></label></th>
            <td><input type="number" id="flight_price" name="flight_price" value="<?php echo esc_attr($price); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_duration"><?php esc_html_e('مدت پرواز', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_duration" name="flight_duration" value="<?php echo esc_attr($duration); ?>" placeholder="مثال: 2 ساعت 30 دقیقه" /></td>
        </tr>
        <tr>
            <th><label for="flight_number"><?php esc_html_e('شماره پرواز', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_number" name="flight_number" value="<?php echo esc_attr($flight_number); ?>" /></td>
        </tr>
    </table>
    <?php
}

// ذخیره داده‌های متاباکس پرواز
function flyairtour_save_flight_meta($post_id) {
    if (!isset($_POST['flyairtour_flight_meta_nonce']) || !wp_verify_nonce($_POST['flyairtour_flight_meta_nonce'], 'flyairtour_flight_meta_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = array(
        'flight_departure_city',
        'flight_arrival_city', 
        'flight_departure_time',
        'flight_arrival_time',
        'flight_price',
        'flight_duration',
        'flight_number'
    );

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'flyairtour_save_flight_meta');

/**
 * Ajax برای جستجو
 */
function flyairtour_ajax_flight_search() {
    check_ajax_referer('flyairtour_nonce', 'nonce');

    $departure = sanitize_text_field($_POST['departure'] ?? '');
    $destination = sanitize_text_field($_POST['destination'] ?? '');
    $departure_date = sanitize_text_field($_POST['departure_date'] ?? '');
    $return_date = sanitize_text_field($_POST['return_date'] ?? '');
    $passengers = intval($_POST['passengers'] ?? 1);

    $args = array(
        'post_type' => 'flight',
        'posts_per_page' => 10,
        'meta_query' => array(
            'relation' => 'AND',
        )
    );

    if (!empty($departure)) {
        $args['meta_query'][] = array(
            'key' => '_flight_departure_city',
            'value' => $departure,
            'compare' => 'LIKE'
        );
    }

    if (!empty($destination)) {
        $args['meta_query'][] = array(
            'key' => '_flight_arrival_city',
            'value' => $destination,
            'compare' => 'LIKE'
        );
    }

    $flights = new WP_Query($args);
    $results = array();

    if ($flights->have_posts()) {
        while ($flights->have_posts()) {
            $flights->the_post();
            $results[] = array(
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'departure_city' => get_post_meta(get_the_ID(), '_flight_departure_city', true),
                'arrival_city' => get_post_meta(get_the_ID(), '_flight_arrival_city', true),
                'departure_time' => get_post_meta(get_the_ID(), '_flight_departure_time', true),
                'arrival_time' => get_post_meta(get_the_ID(), '_flight_arrival_time', true),
                'price' => get_post_meta(get_the_ID(), '_flight_price', true),
                'duration' => get_post_meta(get_the_ID(), '_flight_duration', true),
                'flight_number' => get_post_meta(get_the_ID(), '_flight_number', true),
                'permalink' => get_permalink(),
                'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'flyairtour-medium'),
            );
        }
        wp_reset_postdata();
    }

    wp_send_json_success($results);
}
add_action('wp_ajax_flight_search', 'flyairtour_ajax_flight_search');
add_action('wp_ajax_nopriv_flight_search', 'flyairtour_ajax_flight_search');

/**
 * کاستومایزر وردپرس
 */
function flyairtour_customize_register($wp_customize) {
    // بخش تنظیمات کلی
    $wp_customize->add_section('flyairtour_general', array(
        'title'    => esc_html__('تنظیمات کلی', 'flyairtour-theme'),
        'priority' => 30,
    ));

    // لوگو موبایل
    $wp_customize->add_setting('mobile_logo', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mobile_logo', array(
        'label'    => esc_html__('لوگو موبایل', 'flyairtour-theme'),
        'section'  => 'flyairtour_general',
        'settings' => 'mobile_logo',
    )));

    // شماره تلفن
    $wp_customize->add_setting('contact_phone', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('contact_phone', array(
        'label'   => esc_html__('شماره تلفن', 'flyairtour-theme'),
        'section' => 'flyairtour_general',
        'type'    => 'text',
    ));

    // ایمیل
    $wp_customize->add_setting('contact_email', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_email',
    ));

    $wp_customize->add_control('contact_email', array(
        'label'   => esc_html__('ایمیل', 'flyairtour-theme'),
        'section' => 'flyairtour_general',
        'type'    => 'email',
    ));

    // شبکه‌های اجتماعی
    $social_networks = array(
        'facebook'  => 'فیسبوک',
        'twitter'   => 'توییتر',
        'instagram' => 'اینستاگرام',
        'telegram'  => 'تلگرام',
        'whatsapp'  => 'واتساپ',
        'youtube'   => 'یوتیوب',
    );

    foreach ($social_networks as $network => $label) {
        $wp_customize->ad