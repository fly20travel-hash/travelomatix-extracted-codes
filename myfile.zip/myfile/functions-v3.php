<?php
/**
 * functions.php - فایل توابع تم فلای ایر تور
 * مشابه سیستم Travelomatix با قابلیت‌های کامل
 */

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// ثوابت تم
define('FLYAIRTOUR_VERSION', '1.0.0');
define('FLYAIRTOUR_THEME_DIR', get_template_directory());
define('FLYAIRTOUR_THEME_URI', get_template_directory_uri());

/**
 * تنظیمات اولیه تم
 */
function flyairtour_setup() {
    // پشتیبانی از زبان‌های مختلف
    load_theme_textdomain('flyairtour-theme', get_template_directory() . '/languages');

    // پشتیبانی از تصویر شاخص پست
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(300, 200, true);

    // اندازه‌های مختلف تصاویر
    add_image_size('flyairtour-large', 800, 600, true);
    add_image_size('flyairtour-medium', 400, 300, true);
    add_image_size('flyairtour-small', 200, 150, true);
    add_image_size('flyairtour-deal', 350, 250, true);

    // پشتیبانی از RSS
    add_theme_support('automatic-feed-links');

    // پشتیبانی از عنوان صفحه
    add_theme_support('title-tag');

    // پشتیبانی از HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // پشتیبانی از لوگو سفارشی
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // ثبت منوها
    register_nav_menus(array(
        'primary' => esc_html__('منوی اصلی', 'flyairtour-theme'),
        'footer'  => esc_html__('منوی فوتر', 'flyairtour-theme'),
        'mobile'  => esc_html__('منوی موبایل', 'flyairtour-theme'),
    ));

    // پشتیبانی از ویجت‌ها
    add_theme_support('widgets');

    // پشتیبانی از فرمت‌های پست
    add_theme_support('post-formats', array(
        'gallery',
        'image',
        'video',
        'quote',
        'link'
    ));

    // پشتیبانی از Woocommerce
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'flyairtour_setup');

/**
 * تنظیم عرض محتوا
 */
if (!isset($content_width)) {
    $content_width = 1200;
}

/**
 * بارگذاری استایل‌ها و اسکریپت‌ها
 */
function flyairtour_scripts() {
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');

    // Bootstrap CSS
    wp_enqueue_style('bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/3.4.1/css/bootstrap.min.css', array(), '3.4.1');

    // jQuery UI CSS
    wp_enqueue_style('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/themes/ui-lightness/jquery-ui.min.css', array(), '1.13.2');

    // استایل اصلی تم
    wp_enqueue_style('flyairtour-style', get_stylesheet_uri(), array(), FLYAIRTOUR_VERSION);

    // jQuery (از وردپرس)
    wp_enqueue_script('jquery');

    // Bootstrap JS
    wp_enqueue_script('bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/3.4.1/js/bootstrap.min.js', array('jquery'), '3.4.1', true);

    // jQuery UI
    wp_enqueue_script('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js', array('jquery'), '1.13.2', true);

    // Owl Carousel
    wp_enqueue_style('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css', array(), '2.3.4');
    wp_enqueue_style('owl-theme', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css', array(), '2.3.4');
    wp_enqueue_script('owl-carousel', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js', array('jquery'), '2.3.4', true);

    // اسکریپت سفارشی تم
    wp_enqueue_script('flyairtour-custom', get_template_directory_uri() . '/js/custom.js', array('jquery', 'bootstrap', 'jquery-ui'), FLYAIRTOUR_VERSION, true);

    // متغیرهای Ajax
    wp_localize_script('flyairtour-custom', 'flyairtour_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('flyairtour_nonce'),
        'strings'  => array(
            'loading'      => esc_html__('در حال بارگذاری...', 'flyairtour-theme'),
            'error'        => esc_html__('خطا در برقراری ارتباط', 'flyairtour-theme'),
            'search_error' => esc_html__('لطفاً فیلدهای جستجو را کامل کنید', 'flyairtour-theme'),
        )
    ));

    // اسکریپت نظرات
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'flyairtour_scripts');

/**
 * ثبت sidebar ها و ویجت‌ها
 */
function flyairtour_widgets_init() {
    // سایدبار اصلی
    register_sidebar(array(
        'name'          => esc_html__('سایدبار اصلی', 'flyairtour-theme'),
        'id'            => 'main-sidebar',
        'description'   => esc_html__('ویجت‌های سایدبار اصلی', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    // فوتر - ستون 1
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون اول', 'flyairtour-theme'),
        'id'            => 'footer-1',
        'description'   => esc_html__('ویجت‌های ستون اول فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 2
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون دوم', 'flyairtour-theme'),
        'id'            => 'footer-2',
        'description'   => esc_html__('ویجت‌های ستون دوم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 3
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون سوم', 'flyairtour-theme'),
        'id'            => 'footer-3',
        'description'   => esc_html__('ویجت‌های ستون سوم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));

    // فوتر - ستون 4
    register_sidebar(array(
        'name'          => esc_html__('فوتر - ستون چهارم', 'flyairtour-theme'),
        'id'            => 'footer-4',
        'description'   => esc_html__('ویجت‌های ستون چهارم فوتر', 'flyairtour-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="ftrhd">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'flyairtour_widgets_init');

/**
 * Custom Post Types برای سیستم رزرو
 */

// نوع پست پرواز
function flyairtour_register_flight_post_type() {
    $labels = array(
        'name'               => esc_html__('پروازها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('پرواز', 'flyairtour-theme'),
        'menu_name'          => esc_html__('پروازها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن پرواز جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن پرواز جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('پرواز جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش پرواز', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده پرواز', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه پروازها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی پرواز', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'flights'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-airplane',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'show_in_rest'       => true,
    );

    register_post_type('flight', $args);
}
add_action('init', 'flyairtour_register_flight_post_type');

// نوع پست هتل
function flyairtour_register_hotel_post_type() {
    $labels = array(
        'name'               => esc_html__('هتل‌ها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('هتل', 'flyairtour-theme'),
        'menu_name'          => esc_html__('هتل‌ها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن هتل جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن هتل جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('هتل جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش هتل', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده هتل', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه هتل‌ها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی هتل', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'hotels'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 21,
        'menu_icon'          => 'dashicons-building',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments'),
        'show_in_rest'       => true,
    );

    register_post_type('hotel', $args);
}
add_action('init', 'flyairtour_register_hotel_post_type');

// نوع پست تور
function flyairtour_register_tour_post_type() {
    $labels = array(
        'name'               => esc_html__('تورها', 'flyairtour-theme'),
        'singular_name'      => esc_html__('تور', 'flyairtour-theme'),
        'menu_name'          => esc_html__('تورها', 'flyairtour-theme'),
        'add_new'            => esc_html__('افزودن تور جدید', 'flyairtour-theme'),
        'add_new_item'       => esc_html__('افزودن تور جدید', 'flyairtour-theme'),
        'new_item'           => esc_html__('تور جدید', 'flyairtour-theme'),
        'edit_item'          => esc_html__('ویرایش تور', 'flyairtour-theme'),
        'view_item'          => esc_html__('مشاهده تور', 'flyairtour-theme'),
        'all_items'          => esc_html__('همه تورها', 'flyairtour-theme'),
        'search_items'       => esc_html__('جستجوی تور', 'flyairtour-theme'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'tours'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 22,
        'menu_icon'          => 'dashicons-palmtree',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments'),
        'show_in_rest'       => true,
    );

    register_post_type('tour', $args);
}
add_action('init', 'flyairtour_register_tour_post_type');

/**
 * Custom Taxonomies
 */

// تکسونومی مقاصد
function flyairtour_register_destination_taxonomy() {
    $labels = array(
        'name'              => esc_html__('مقاصد', 'flyairtour-theme'),
        'singular_name'     => esc_html__('مقصد', 'flyairtour-theme'),
        'search_items'      => esc_html__('جستجوی مقصد', 'flyairtour-theme'),
        'all_items'         => esc_html__('همه مقاصد', 'flyairtour-theme'),
        'parent_item'       => esc_html__('مقصد والد', 'flyairtour-theme'),
        'parent_item_colon' => esc_html__('مقصد والد:', 'flyairtour-theme'),
        'edit_item'         => esc_html__('ویرایش مقصد', 'flyairtour-theme'),
        'update_item'       => esc_html__('بروزرسانی مقصد', 'flyairtour-theme'),
        'add_new_item'      => esc_html__('افزودن مقصد جدید', 'flyairtour-theme'),
        'new_item_name'     => esc_html__('نام مقصد جدید', 'flyairtour-theme'),
        'menu_name'         => esc_html__('مقاصد', 'flyairtour-theme'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'destination'),
        'show_in_rest'      => true,
    );

    register_taxonomy('destination', array('flight', 'hotel', 'tour'), $args);
}
add_action('init', 'flyairtour_register_destination_taxonomy');

// تکسونومی شرکت‌های هواپیمایی
function flyairtour_register_airline_taxonomy() {
    $labels = array(
        'name'              => esc_html__('شرکت‌های هواپیمایی', 'flyairtour-theme'),
        'singular_name'     => esc_html__('شرکت هواپیمایی', 'flyairtour-theme'),
        'search_items'      => esc_html__('جستجوی شرکت', 'flyairtour-theme'),
        'all_items'         => esc_html__('همه شرکت‌ها', 'flyairtour-theme'),
        'edit_item'         => esc_html__('ویرایش شرکت', 'flyairtour-theme'),
        'update_item'       => esc_html__('بروزرسانی شرکت', 'flyairtour-theme'),
        'add_new_item'      => esc_html__('افزودن شرکت جدید', 'flyairtour-theme'),
        'new_item_name'     => esc_html__('نام شرکت جدید', 'flyairtour-theme'),
        'menu_name'         => esc_html__('شرکت‌های هواپیمایی', 'flyairtour-theme'),
    );

    $args = array(
        'hierarchical'      => false,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'airline'),
        'show_in_rest'      => true,
    );

    register_taxonomy('airline', array('flight'), $args);
}
add_action('init', 'flyairtour_register_airline_taxonomy');

/**
 * Meta Boxes برای اطلاعات اضافی
 */

// متاباکس اطلاعات پرواز
function flyairtour_add_flight_metabox() {
    add_meta_box(
        'flight-details',
        esc_html__('جزئیات پرواز', 'flyairtour-theme'),
        'flyairtour_flight_metabox_callback',
        'flight',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'flyairtour_add_flight_metabox');

function flyairtour_flight_metabox_callback($post) {
    wp_nonce_field('flyairtour_flight_meta_nonce', 'flyairtour_flight_meta_nonce');
    
    $departure_city = get_post_meta($post->ID, '_flight_departure_city', true);
    $arrival_city = get_post_meta($post->ID, '_flight_arrival_city', true);
    $departure_time = get_post_meta($post->ID, '_flight_departure_time', true);
    $arrival_time = get_post_meta($post->ID, '_flight_arrival_time', true);
    $price = get_post_meta($post->ID, '_flight_price', true);
    $duration = get_post_meta($post->ID, '_flight_duration', true);
    $flight_number = get_post_meta($post->ID, '_flight_number', true);
    ?>
    <table class="form-table">
        <tr>
            <th><label for="flight_departure_city"><?php esc_html_e('شهر مبدا', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_departure_city" name="flight_departure_city" value="<?php echo esc_attr($departure_city); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_arrival_city"><?php esc_html_e('شهر مقصد', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_arrival_city" name="flight_arrival_city" value="<?php echo esc_attr($arrival_city); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_departure_time"><?php esc_html_e('زمان حرکت', 'flyairtour-theme'); ?></label></th>
            <td><input type="datetime-local" id="flight_departure_time" name="flight_departure_time" value="<?php echo esc_attr($departure_time); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_arrival_time"><?php esc_html_e('زمان رسیدن', 'flyairtour-theme'); ?></label></th>
            <td><input type="datetime-local" id="flight_arrival_time" name="flight_arrival_time" value="<?php echo esc_attr($arrival_time); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_price"><?php esc_html_e('قیمت (تومان)', 'flyairtour-theme'); ?></label></th>
            <td><input type="number" id="flight_price" name="flight_price" value="<?php echo esc_attr($price); ?>" /></td>
        </tr>
        <tr>
            <th><label for="flight_duration"><?php esc_html_e('مدت پرواز', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_duration" name="flight_duration" value="<?php echo esc_attr($duration); ?>" placeholder="مثال: 2 ساعت 30 دقیقه" /></td>
        </tr>
        <tr>
            <th><label for="flight_number"><?php esc_html_e('شماره پرواز', 'flyairtour-theme'); ?></label></th>
            <td><input type="text" id="flight_number" name="flight_number" value="<?php echo esc_attr($flight_number); ?>" /></td>
        </tr>
    </table>
    <?php
}

// ذخیره داده‌های متاباکس پرواز
function flyairtour_save_flight_meta($post_id) {
    if (!isset($_POST['flyairtour_flight_meta_nonce']) || !wp_verify_nonce($_POST['flyairtour_flight_meta_nonce'], 'flyairtour_flight_meta_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = array(
        'flight_departure_city',
        'flight_arrival_city', 
        'flight_departure_time',
        'flight_arrival_time',
        'flight_price',
        'flight_duration',
        'flight_number'
    );

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'flyairtour_save_flight_meta');

/**
 * Ajax برای جستجو
 */
function flyairtour_ajax_flight_search() {
    check_ajax_referer('flyairtour_nonce', 'nonce');

    $departure = sanitize_text_field($_POST['departure'] ?? '');
    $destination = sanitize_text_field($_POST['destination'] ?? '');
    $departure_date = sanitize_text_field($_POST['departure_date'] ?? '');
    $return_date = sanitize_text_field($_POST['return_date'] ?? '');
    $passengers = intval($_POST['passengers'] ?? 1);

    $args = array(
        'post_type' => 'flight',
        'posts_per_page' => 10,
        'meta_query' => array(
            'relation' => 'AND',
        )
    );

    if (!empty($departure)) {
        $args['meta_query'][] = array(
            'key' => '_flight_departure_city',
            'value' => $departure,
            'compare' => 'LIKE'
        );
    }

    if (!empty($destination)) {
        $args['meta_query'][] = array(
            'key' => '_flight_arrival_city',
            'value' => $destination,
            'compare' => 'LIKE'
        );
    }

    $flights = new WP_Query($args);
    $results = array();

    if ($flights->have_posts()) {
        while ($flights->have_posts()) {
            $flights->the_post();
            $results[] = array(
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'departure_city' => get_post_meta(get_the_ID(), '_flight_departure_city', true),
                'arrival_city' => get_post_meta(get_the_ID(), '_flight_arrival_city', true),
                'departure_time' => get_post_meta(get_the_ID(), '_flight_departure_time', true),
                'arrival_time' => get_post_meta(get_the_ID(), '_flight_arrival_time', true),
                'price' => get_post_meta(get_the_ID(), '_flight_price', true),
                'duration' => get_post_meta(get_the_ID(), '_flight_duration', true),
                'flight_number' => get_post_meta(get_the_ID(), '_flight_number', true),
                'permalink' => get_permalink(),
                'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'flyairtour-medium'),
            );
        }
        wp_reset_postdata();
    }

    wp_send_json_success($results);
}
add_action('wp_ajax_flight_search', 'flyairtour_ajax_flight_search');
add_action('wp_ajax_nopriv_flight_search', 'flyairtour_ajax_flight_search');

/**
 * کاستومایزر وردپرس
 */
function flyairtour_customize_register($wp_customize) {
    // بخش تنظیمات کلی
    $wp_customize->add_section('flyairtour_general', array(
        'title'    => esc_html__('تنظیمات کلی', 'flyairtour-theme'),
        'priority' => 30,
    ));

    // لوگو موبایل
    $wp_customize->add_setting('mobile_logo', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mobile_logo', array(
        'label'    => esc_html__('لوگو موبایل', 'flyairtour-theme'),
        'section'  => 'flyairtour_general',
        'settings' => 'mobile_logo',
    )));

    // شماره تلفن
    $wp_customize->add_setting('contact_phone', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('contact_phone', array(
        'label'   => esc_html__('شماره تلفن', 'flyairtour-theme'),
        'section' => 'flyairtour_general',
        'type'    => 'text',
    ));

    // ایمیل
    $wp_customize->add_setting('contact_email', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_email',
    ));

    $wp_customize->add_control('contact_email', array(
        'label'   => esc_html__('ایمیل', 'flyairtour-theme'),
        'section' => 'flyairtour_general',
        'type'    => 'email',
    ));

    // شبکه‌های اجتماعی
    $social_networks = array(
        'facebook'  => 'فیسبوک',
        'twitter'   => 'توییتر',
        'instagram' => 'اینستاگرام',
        'telegram'  => 'تلگرام',
        'whatsapp'  => 'واتساپ',
        'youtube'   => 'یوتیوب',
    );

    foreach ($social_networks as $network => $label) {
        $wp_customize->add_setting('social_' . $network, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ));

        $wp_customize->add_control('social_' . $network, array(
            'label'   => $label,
            'section' => 'flyairtour_general',
            'type'    => 'url',
        ));
    }

    // رنگ‌های تم
    $wp_customize->add_section('flyairtour_colors', array(
        'title'    => esc_html__('رنگ‌های تم', 'flyairtour-theme'),
        'priority' => 31,
    ));

    // رنگ اصلی
    $wp_customize->add_setting('primary_color', array(
        'default'           => '#00a9d6',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label'   => esc_html__('رنگ اصلی', 'flyairtour-theme'),
        'section' => 'flyairtour_colors',
    )));

    // رنگ ثانویه
    $wp_customize->add_setting('secondary_color', array(
        'default'           => '#ff9800',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label'   => esc_html__('رنگ ثانویه', 'flyairtour-theme'),
        'section' => 'flyairtour_colors',
    )));
}
add_action('customize_register', 'flyairtour_customize_register');

/**
 * فونت‌های Google
 */
function flyairtour_google_fonts() {
    $fonts = array(
        'Vazir:300,400,500,600,700',
        'Lato:300,400,700',
        'Source+Sans+Pro:300,400,600,700'
    );
    
    $fonts_url = add_query_arg(array(
        'family' => implode('|', $fonts),
        'subset' => 'latin,arabic',
        'display' => 'swap',
    ), 'https://fonts.googleapis.com/css');

    return $fonts_url;
}

/**
 * تابع برای نمایش ستاره‌های امتیاز
 */
function flyairtour_star_rating($rating = 5, $max_rating = 5) {
    $output = '<div class="rating-stars">';
    
    for ($i = 1; $i <= $max_rating; $i++) {
        if ($i <= $rating) {
            $output .= '<i class="fas fa-star"></i>';
        } elseif ($i - 0.5 <= $rating) {
            $output .= '<i class="fas fa-star-half-alt"></i>';
        } else {
            $output .= '<i class="far fa-star"></i>';
        }
    }
    
    $output .= '</div>';
    return $output;
}

/**
 * تابع برای فرمت قیمت
 */
function flyairtour_format_price($price, $currency = 'تومان') {
    if (empty($price) || !is_numeric($price)) {
        return esc_html__('قیمت نامشخص', 'flyairtour-theme');
    }
    
    return number_format($price) . ' ' . $currency;
}

/**
 * تابع برای محاسبه تخفیف
 */
function flyairtour_calculate_discount($original_price, $sale_price) {
    if (!is_numeric($original_price) || !is_numeric($sale_price) || $original_price <= $sale_price) {
        return 0;
    }
    
    return round((($original_price - $sale_price) / $original_price) * 100);
}

/**
 * تابع برای نمایش اطلاعات نویسنده
 */
function flyairtour_author_info() {
    $author_id = get_the_author_meta('ID');
    $author_name = get_the_author();
    $author_bio = get_the_author_meta('description');
    $author_url = get_author_posts_url($author_id);
    $author_avatar = get_avatar($author_id, 80);
    
    if (!empty($author_bio)) {
        echo '<div class="author-info">';
        echo '<div class="author-avatar">' . $author_avatar . '</div>';
        echo '<div class="author-details">';
        echo '<h4><a href="' . esc_url($author_url) . '">' . esc_html($author_name) . '</a></h4>';
        echo '<p>' . esc_html($author_bio) . '</p>';
        echo '</div>';
        echo '</div>';
    }
}

/**
 * تابع برای نمایش مقالات مرتبط
 */
function flyairtour_related_posts($post_id = null, $limit = 3) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }

    $categories = wp_get_post_categories($post_id);
    
    if (empty($categories)) {
        return;
    }

    $args = array(
        'category__in'   => $categories,
        'post__not_in'   => array($post_id),
        'posts_per_page' => $limit,
        'orderby'        => 'rand',
    );

    $related_posts = new WP_Query($args);

    if ($related_posts->have_posts()) {
        echo '<div class="related-posts">';
        echo '<h3>' . esc_html__('مقالات مرتبط', 'flyairtour-theme') . '</h3>';
        echo '<div class="related-posts-grid">';
        
        while ($related_posts->have_posts()) {
            $related_posts->the_post();
            echo '<div class="related-post-item">';
            
            if (has_post_thumbnail()) {
                echo '<div class="related-post-thumbnail">';
                echo '<a href="' . get_permalink() . '">';
                the_post_thumbnail('flyairtour-small');
                echo '</a>';
                echo '</div>';
            }
            
            echo '<div class="related-post-content">';
            echo '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
            echo '<div class="related-post-meta">';
            echo '<span class="post-date">' . get_the_date() . '</span>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
        wp_reset_postdata();
    }
}

/**
 * تابع برای نمایش breadcrumb
 */
function flyairtour_breadcrumb() {
    if (is_front_page()) {
        return;
    }

    echo '<div class="breadcrumb-container">';
    echo '<div class="container">';
    echo '<nav class="breadcrumb">';
    echo '<a href="' . home_url('/') . '">' . esc_html__('خانه', 'flyairtour-theme') . '</a>';

    if (is_category() || is_single()) {
        echo '<span class="separator"> / </span>';
        the_category(', ');
        
        if (is_single()) {
            echo '<span class="separator"> / </span>';
            echo '<span class="current">' . get_the_title() . '</span>';
        }
    } elseif (is_page()) {
        echo '<span class="separator"> / </span>';
        echo '<span class="current">' . get_the_title() . '</span>';
    } elseif (is_archive()) {
        echo '<span class="separator"> / </span>';
        echo '<span class="current">' . get_the_archive_title() . '</span>';
    } elseif (is_search()) {
        echo '<span class="separator"> / </span>';
        echo '<span class="current">' . esc_html__('نتایج جستجو برای: ', 'flyairtour-theme') . get_search_query() . '</span>';
    } elseif (is_404()) {
        echo '<span class="separator"> / </span>';
        echo '<span class="current">' . esc_html__('صفحه یافت نشد', 'flyairtour-theme') . '</span>';
    }

    echo '</nav>';
    echo '</div>';
    echo '</div>';
}

/**
 * محدود کردن تعداد کلمات excerpt
 */
function flyairtour_custom_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'flyairtour_custom_excerpt_length', 999);

/**
 * تغییر متن "ادامه مطلب"
 */
function flyairtour_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'flyairtour_excerpt_more');

/**
 * افزودن کلاس‌های CSS به body
 */
function flyairtour_body_classes($classes) {
    // افزودن کلاس RTL
    $classes[] = 'rtl';
    
    // افزودن کلاس نوع صفحه
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    
    if (is_single()) {
        $classes[] = 'single-post';
    }
    
    if (is_page()) {
        $classes[] = 'single-page';
    }
    
    // افزودن کلاس برای sidebar
    if (is_active_sidebar('main-sidebar')) {
        $classes[] = 'has-sidebar';
    } else {
        $classes[] = 'no-sidebar';
    }
    
    return $classes;
}
add_filter('body_class', 'flyairtour_body_classes');

/**
 * پشتیبانی از SVG
 */
function flyairtour_svg_upload_support($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'flyairtour_svg_upload_support');

/**
 * بهینه‌سازی تصاویر
 */
function flyairtour_responsive_images($html, $post_id, $post_image_id) {
    $html = str_replace('<img', '<img loading="lazy"', $html);
    return $html;
}
add_filter('post_thumbnail_html', 'flyairtour_responsive_images', 10, 3);

/**
 * ویجت سفارشی برای اطلاعات تماس
 */
class Flyairtour_Contact_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'flyairtour_contact_widget',
            esc_html__('اطلاعات تماس فلای ایر تور', 'flyairtour-theme'),
            array(
                'description' => esc_html__('نمایش اطلاعات تماس در سایدبار', 'flyairtour-theme'),
            )
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        
        echo '<div class="contact-info">';
        
        if (!empty($instance['phone'])) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-phone"></i>';
            echo '<span>' . esc_html($instance['phone']) . '</span>';
            echo '</div>';
        }
        
        if (!empty($instance['email'])) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-envelope"></i>';
            echo '<span>' . esc_html($instance['email']) . '</span>';
            echo '</div>';
        }
        
        if (!empty($instance['address'])) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-map-marker-alt"></i>';
            echo '<span>' . esc_html($instance['address']) . '</span>';
            echo '</div>';
        }
        
        if (!empty($instance['hours'])) {
            echo '<div class="contact-item">';
            echo '<i class="fas fa-clock"></i>';
            echo '<span>' . esc_html($instance['hours']) . '</span>';
            echo '</div>';
        }
        
        echo '</div>';
        
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : esc_html__('اطلاعات تماس', 'flyairtour-theme');
        $phone = !empty($instance['phone']) ? $instance['phone'] : '';
        $email = !empty($instance['email']) ? $instance['email'] : '';
        $address = !empty($instance['address']) ? $instance['address'] : '';
        $hours = !empty($instance['hours']) ? $instance['hours'] : '';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('عنوان:', 'flyairtour-theme'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone')); ?>"><?php esc_attr_e('شماره تلفن:', 'flyairtour-theme'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('phone')); ?>" name="<?php echo esc_attr($this->get_field_name('phone')); ?>" type="text" value="<?php echo esc_attr($phone); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email')); ?>"><?php esc_attr_e('ایمیل:', 'flyairtour-theme'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('email')); ?>" name="<?php echo esc_attr($this->get_field_name('email')); ?>" type="email" value="<?php echo esc_attr($email); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('address')); ?>"><?php esc_attr_e('آدرس:', 'flyairtour-theme'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('address')); ?>" name="<?php echo esc_attr($this->get_field_name('address')); ?>" rows="3"><?php echo esc_attr($address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('hours')); ?>"><?php esc_attr_e('ساعات کاری:', 'flyairtour-theme'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('hours')); ?>" name="<?php echo esc_attr($this->get_field_name('hours')); ?>" type="text" value="<?php echo esc_attr($hours); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['phone'] = (!empty($new_instance['phone'])) ? sanitize_text_field($new_instance['phone']) : '';
        $instance['email'] = (!empty($new_instance['email'])) ? sanitize_email($new_instance['email']) : '';
        $instance['address'] = (!empty($new_instance['address'])) ? sanitize_textarea_field($new_instance['address']) : '';
        $instance['hours'] = (!empty($new_instance['hours'])) ? sanitize_text_field($new_instance['hours']) : '';

        return $instance;
    }
}

// ثبت ویجت
function flyairtour_register_widgets() {
    register_widget('Flyairtour_Contact_Widget');
}
add_action('widgets_init', 'flyairtour_register_widgets');

/**
 * اضافه کردن متا تگ‌های SEO
 */
function flyairtour_add_meta_tags() {
    if (is_single() || is_page()) {
        global $post;
        
        echo '<meta name="description" content="' . esc_attr(wp_strip_all_tags(get_the_excerpt())) . '">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr(get_the_title()) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(wp_strip_all_tags(get_the_excerpt())) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '">' . "\n";
        echo '<meta property="og:type" content="article">' . "\n";
        
        if (has_post_thumbnail()) {
            $image_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
            echo '<meta property="og:image" content="' . esc_url($image_url) . '">' . "\n";
        }
        
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr(get_the_title()) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr(wp_strip_all_tags(get_the_excerpt())) . '">' . "\n";
    }
}
add_action('wp_head', 'flyairtour_add_meta_tags');

/**
 * بهینه‌سازی سرعت بارگذاری
 */
function flyairtour_optimize_scripts() {
    // حذف emoji scripts
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    
    // حذف RSD link
    remove_action('wp_head', 'rsd_link');
    
    // حذف Windows Live Writer
    remove_action('wp_head', 'wlwmanifest_link');
    
    // حذف نسخه وردپرس از header
    remove_action('wp_head', 'wp_generator');
}
add_action('init', 'flyairtour_optimize_scripts');

/**
 * افزودن Schema Markup برای SEO
 */
function flyairtour_add_schema_markup() {
    if (is_single() && get_post_type() == 'flight') {
        $departure_city = get_post_meta(get_the_ID(), '_flight_departure_city', true);
        $arrival_city = get_post_meta(get_the_ID(), '_flight_arrival_city', true);
        $price = get_post_meta(get_the_ID(), '_flight_price', true);
        $departure_time = get_post_meta(get_the_ID(), '_flight_departure_time', true);
        $arrival_time = get_post_meta(get_the_ID(), '_flight_arrival_time', true);
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Flight',
            'flightNumber' => get_post_meta(get_the_ID(), '_flight_number', true),
            'departureAirport' => array(
                '@type' => 'Airport',
                'name' => $departure_city
            ),
            'arrivalAirport' => array(
                '@type' => 'Airport', 
                'name' => $arrival_city
            ),
            'departureTime' => $departure_time,
            'arrivalTime' => $arrival_time,
            'offers' => array(
                '@type' => 'Offer',
                'price' => $price,
                'priceCurrency' => 'IRR',
                'availability' => 'https://schema.org/InStock'
            )
        );
        
        echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
    }
}
add_action('wp_head', 'flyairtour_add_schema_markup');

/**
 * حذف jQuery migrate
 */
function flyairtour_remove_jquery_migrate($scripts) {
    if (!is_admin() && isset($scripts->registered['jquery'])) {
        $script = $scripts->registered['jquery'];
        if ($script->deps) {
            $script->deps = array_diff($script->deps, array('jquery-migrate'));
        }
    }
}
add_action('wp_default_scripts', 'flyairtour_remove_jquery_migrate');

/**
 * تابع برای پاکسازی کد HTML
 */
function flyairtour_clean_html($buffer) {
    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
    return $buffer;
}

/**
 * فعال‌سازی فشرده‌سازی HTML در حالت production
 */
if (!WP_DEBUG) {
    function flyairtour_buffer_start() { 
        ob_start("flyairtour_clean_html"); 
    }
    
    function flyairtour_buffer_end() { 
        ob_end_flush(); 
    }
    
    add_action('wp_loaded', 'flyairtour_buffer_start');
    add_action('shutdown', 'flyairtour_buffer_end');
}

/**
 * تابع برای تبدیل اعداد انگلیسی به فارسی
 */
function flyairtour_persian_numbers($string) {
    $english = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    $persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    
    return str_replace($english, $persian, $string);
}

/**
 * اضافه کردن support برای WebP
 */
function flyairtour_webp_support($mimes) {
    $mimes['webp'] = 'image/webp';
    return $mimes;
}
add_filter('upload_mimes', 'flyairtour_webp_support');

/**
 * آماده‌سازی برای ترجمه
 */
function flyairtour_load_textdomain() {
    load_theme_textdomain('flyairtour-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'flyairtour_load_textdomain');

/**
 * پایان فایل functions.php
 */
?>