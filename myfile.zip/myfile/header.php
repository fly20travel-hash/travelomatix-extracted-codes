<?php
/**
 * header.php - هدر تم فلای ایر تور
 * مشابه هدر Travelomatix
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
    
    <!-- SEO Meta Tags -->
    <?php if (is_home() || is_front_page()) : ?>
    <meta name="keywords" content="<?php echo esc_attr(get_bloginfo('description')); ?>, پرواز, هتل, تور, مسافرت, رزرو">
    <meta name="description" content="<?php echo esc_attr(get_bloginfo('description')); ?>">
    <?php endif; ?>
    
    <meta name="author" content="<?php bloginfo('name'); ?>">
    
    <!-- Favicon -->
    <?php 
    $favicon = get_theme_mod('favicon', get_template_directory_uri() . '/images/favicon.ico');
    ?>
    <link rel="shortcut icon" href="<?php echo esc_url($favicon); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo esc_url($favicon); ?>" type="image/x-icon">
    
    <!-- Preload Important Resources -->
    <link rel="preload" href="<?php echo flyairtour_google_fonts(); ?>" as="style">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <?php wp_head(); ?>
    
    <!-- Custom CSS از کاستومایزر -->
    <style>
    :root {
        --primary-color: <?php echo esc_html(get_theme_mod('primary_color', '#00a9d6')); ?>;
        --secondary-color: <?php echo esc_html(get_theme_mod('secondary_color', '#ff9800')); ?>;
    }
    
    .searchsbmt,
    .btn-primary,
    .totlall::before {
        background-color: var(--primary-color);
    }
    
    .pagehding,
    .searchsbmt:hover {
        color: var(--secondary-color);
    }
    
    .service-icon i {
        color: var(--primary-color);
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .service-item {
        padding: 2rem 1rem;
        margin-bottom: 2rem;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .service-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }
    
    .blog-post-item {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        overflow: hidden;
        margin-bottom: 2rem;
        transition: transform 0.3s ease;
    }
    
    .blog-post-item:hover {
        transform: translateY(-5px);
    }
    
    .post-content {
        padding: 1.5rem;
    }
    
    .post-title a {
        color: #333;
        text-decoration: none;
    }
    
    .post-title a:hover {
        color: var(--primary-color);
    }
    
    .post-meta {
        color: #666;
        font-size: 0.9rem;
        margin: 0.5rem 0 1rem;
    }
    
    .post-meta span {
        margin-left: 1rem;
    }
    
    .read-more {
        color: var(--primary-color);
        font-weight: 500;
        text-decoration: none;
    }
    
    .read-more:hover {
        color: var(--secondary-color);
    }
    
    /* استایل‌های ریسپانسیو */
    @media (max-width: 768px) {
        .service-item {
            margin-bottom: 1rem;
            padding: 1rem;
        }
        
        .service-icon i {
            font-size: 2rem;
        }
    }
    </style>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    
    <!-- Header Start -->
    <header>
        <!-- Top Section -->
        <div class="section_top">
            <div class="container">
                <div class="topalstn">
                    <!-- Social Links -->
                    <div class="socila hidesocial">
                        <?php
                        $social_networks = array(
                            'facebook' => 'fab fa-facebook-f',
                            'twitter' => 'fab fa-twitter',
                            'instagram' => 'fab fa-instagram',
                            'telegram' => 'fab fa-telegram-plane',
                            'whatsapp' => 'fab fa-whatsapp',
                            'youtube' => 'fab fa-youtube'
                        );
                        
                        foreach ($social_networks as $network => $icon) {
                            $url = get_theme_mod('social_' . $network);
                            if ($url) {
                                echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener"><i class="' . esc_attr($icon) . '"></i></a>';
                            }
                        }
                        ?>
                    </div>
                    
                    <!-- Contact Info -->
                    <div class="toprit">
                        <?php 
                        $contact_phone = get_theme_mod('contact_phone');
                        $contact_email = get_theme_mod('contact_email');
                        ?>
                        
                        <?php if ($contact_phone) : ?>
                        <div class="sectns">
                            <a class="phnumr" href="tel:<?php echo esc_attr($contact_phone); ?>">
                                <span class="fa fa-phone cliktocl"></span>
                                <span class="numhide"><?php echo esc_html($contact_phone); ?></span>
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($contact_email) : ?>
                        <div class="sectns">
                            <a class="mailadrs" href="mailto:<?php echo esc_attr($contact_email); ?>">
                                <span class="fa fa-envelope"></span>
                                <?php echo esc_html($contact_email); ?>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Navigation -->
        <div class="topssec">
            <div class="container">
                <!-- Mobile Menu Toggle -->
                <div class="bars_menu fa fa-bars menu_brgr"></div>
                
                <!-- Logo -->
                <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">
                    <?php
                    $mobile_logo = get_theme_mod('mobile_logo');
                    $custom_logo_id = get_theme_mod('custom_logo');
                    
                    if ($mobile_logo && wp_is_mobile()) {
                        echo '<img class="tab_logo" src="' . esc_url($mobile_logo) . '" alt="' . esc_attr(get_bloginfo('name')) . '" />';
                    }
                    
                    if ($custom_logo_id) {
                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                        echo '<img class="ful_logo" src="' . esc_url($logo[0]) . '" alt="' . esc_attr(get_bloginfo('name')) . '" />';
                    } else {
                        echo '<img class="ful_logo" src="' . get_template_directory_uri() . '/images/logo.png" alt="' . esc_attr(get_bloginfo('name')) . '" />';
                    }
                    ?>
                </a>
                
                <!-- Navigation Menu -->
                <div class="menuandall">
                    <div class="sepmenus">
                        <?php if (has_nav_menu('primary')) : ?>
                            <?php
                            wp_nav_menu(array(
                                'theme_location' => 'primary',
                                'menu_class' => 'exploreall',
                                'container' => false,
                                'depth' => 2,
                                'walker' => new Flyairtour_Nav_Walker()
                            ));
                            ?>
                        <?php else : ?>
                            <ul class="exploreall">
                                <li><a href="<?php echo esc_url(home_url('/flights')); ?>">
                                    <span class="sprte cmnexplor icnhnflight"></span>
                                    <strong><?php esc_html_e('پروازها', 'flyairtour-theme'); ?></strong>
                                </a></li>
                                <li><a href="<?php echo esc_url(home_url('/hotels')); ?>">
                                    <span class="sprte cmnexplor icnhtl"></span>
                                    <strong><?php esc_html_e('هتل‌ها', 'flyairtour-theme'); ?></strong>
                                </a></li>
                                <li><a href="<?php echo esc_url(home_url('/tours')); ?>">
                                    <span class="sprte cmnexplor icnhnhlydy"></span>
                                    <strong><?php esc_html_e('تورها', 'flyairtour-theme'); ?></strong>
                                </a></li>
                                <li><a href="<?php echo esc_url(home_url('/buses')); ?>">
                                    <span class="sprte cmnexplor icnhnbus"></span>
                                    <strong><?php esc_html_e('اتوبوس', 'flyairtour-theme'); ?></strong>
                                </a></li>
                                <li><a href="<?php echo esc_url(home_url('/contact')); ?>">
                                    <span class="sprte cmnexplor"></span>
                                    <strong><?php esc_html_e('تماس با ما', 'flyairtour-theme'); ?></strong>
                                </a></li>
                            </ul>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Right Side Menu -->
                    <div class="ritsude">
                        <!-- User Account -->
                        <div class="sidebtn">
                            <?php if (is_user_logged_in()) : ?>
                                <?php $current_user = wp_get_current_user(); ?>
                                <a class="topa logindown dropdown-toggle" data-toggle="dropdown">
                                    <div class="reglog">
                                        <div class="userimage">
                                            <?php echo get_avatar($current_user->ID, 30); ?>
                                        </div>
                                        <div class="userorlogin">
                                            <?php echo esc_html($current_user->display_name); ?>
                                        </div>
                                    </div>
                                    <b class="caret cartdown"></b>
                                </a>
                                
                                <!-- User Dropdown Menu -->
                                <ul class="dropdown-menu exploreul logdowndiv">
                                    <li><a href="<?php echo esc_url(home_url('/my-account')); ?>">
                                        <i class="fas fa-user"></i> حساب کاربری
                                    </a></li>
                                    <li><a href="<?php echo esc_url(home_url('/my-bookings')); ?>">
                                        <i class="fas fa-list-alt"></i> رزروهای من
                                    </a></li>
                                    <li><a href="<?php echo esc_url(home_url('/profile')); ?>">
                                        <i class="fas fa-edit"></i> ویرایش پروفایل
                                    </a></li>
                                    <li class="divider"></li>
                                    <li><a href="<?php echo wp_logout_url(home_url()); ?>">
                                        <i class="fas fa-sign-out-alt"></i> خروج
                                    </a></li>
                                </ul>
                            <?php else : ?>
                                <a class="topa logindown" data-toggle="modal" data-target="#show_log">
                                    <div class="reglog">
                                        <div class="userimage">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/user.png" alt="user" />
                                        </div>
                                        <div class="userorlogin"><?php esc_html_e('ورود / ثبت‌نام', 'flyairtour-theme'); ?></div>
                                    </div>
                                </a>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Currency Selector -->
                        <div class="sidebtn flagss">
                            <a class="topa dropdown-toggle" data-toggle="dropdown">
                                <div class="reglognorml">
                                    <div class="flag_images">
                                        <span class="curncy_img sprte inr"></span>
                                    </div>
                                    <div class="flags">تومان</div>
                                    <b class="caret cartdown"></b>
                                </div>
                            </a>
                            
                            <ul class="dropdown-menu exploreul explorecntry logdowndiv">
                                <li class="currency_li active">
                                    <a href="#" data-currency="IRR">
                                        <span class="curncy_img sprte irr"></span>
                                        <span class="name_currency">تومان</span>
                                        <span class="side_curency">تومان</span>
                                    </a>
                                </li>
                                <li class="currency_li">
                                    <a href="#" data-currency="USD">
                                        <span class="curncy_img sprte usd"></span>
                                        <span class="name_currency">USD</span>
                                        <span class="side_curency">$</span>
                                    </a>
                                </li>
                                <li class="currency_li">
                                    <a href="#" data-currency="EUR">
                                        <span class="curncy_img sprte eur"></span>
                                        <span class="name_currency">EUR</span>
                                        <span class="side_curency">€</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Login/Register Modal -->
    <?php if (!is_user_logged_in()) : ?>
    <div id="show_log" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="my_account_dropdown mysign exploreul">
                        <button type="button" class="close log_close" data-dismiss="modal">&times;</button>
                        
                        <!-- Login Tab -->
                        <div class="insigndiv for_sign_in">
                            <div class="ritpul">
                                <form role="form" id="login_form" action="<?php echo esc_url(wp_login_url()); ?>" method="post">
                                    <div class="rowput">
                                        <span class="fa fa-user"></span>
                                        <input type="email" id="user_login" class="form-control logpadding" placeholder="ایمیل یا نام کاربری" name="log" required />
                                    </div>
                                    
                                    <div class="rowput">
                                        <span class="fa fa-lock"></span>
                                        <input type="password" id="user_pass" class="form-control logpadding" placeholder="رمز عبور" name="pwd" required />
                                    </div>
                                    
                                    <div class="misclog">
                                        <a class="hand-cursor forgtpsw" href="<?php echo wp_lostpassword_url(); ?>">
                                            <?php esc_html_e('فراموشی رمز عبور؟', 'flyairtour-theme'); ?>
                                        </a>
                                    </div>
                                    
                                    <button type="submit" class="submitlogin">
                                        <?php esc_html_e('ورود', 'flyairtour-theme'); ?>
                                    </button>
                                    
                                    <div class="dntacnt">
                                        <?php esc_html_e('کاربر جدید هستید؟', 'flyairtour-theme'); ?>
                                        <a class="hand-cursor open_register"><?php esc_html_e('ثبت‌نام', 'flyairtour-theme'); ?></a>
                                    </div>
                                    
                                    <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>
                                </form>
                            </div>
                        </div>

                        <!-- Register Tab -->
                        <div class="newacount_div for_sign_up" style="display: none;">
                            <div class="slpophd_new"><?php esc_html_e('ثبت‌نام در فلای ایر تور', 'flyairtour-theme'); ?></div>
                            <div class="othesend_regstr">
                                <div class="ritpul">
                                    <form id="register_form" method="post">
                                        <div class="rowput">
                                            <span class="fa fa-user"></span>
                                            <input type="text" class="form-control logpadding" placeholder="نام و نام خانوادگی" name="display_name" required />
                                        </div>
                                        
                                        <div class="rowput">
                                            <span class="fa fa-envelope"></span>
                                            <input type="email" class="form-control logpadding" placeholder="آدرس ایمیل" name="user_email" required />
                                        </div>
                                        
                                        <div class="rowput">
                                            <span class="fa fa-phone"></span>
                                            <input type="tel" class="form-control logpadding" placeholder="شماره موبایل" name="phone" required />
                                        </div>
                                        
                                        <div class="rowput">
                                            <span class="fa fa-lock"></span>
                                            <input type="password" class="form-control logpadding" placeholder="رمز عبور" name="user_pass" required />
                                        </div>
                                        
                                        <div class="rowput">
                                            <span class="fa fa-lock"></span>
                                            <input type="password" class="form-control logpadding" placeholder="تکرار رمز عبور" name="confirm_password" required />
                                        </div>
                                        
                                        <div class="row_submit">
                                            <div class="agree_terms">
                                                <label>
                                                    <input type="checkbox" name="terms" required />
                                                    <?php esc_html_e('با ', 'flyairtour-theme'); ?>
                                                    <a href="<?php echo get_privacy_policy_url(); ?>" target="_blank">
                                                        <?php esc_html_e('قوانین و مقررات', 'flyairtour-theme'); ?>
                                                    </a>
                                                    <?php esc_html_e(' موافق هستم', 'flyairtour-theme'); ?>
                                                </label>
                                            </div>
                                            
                                            <button type="submit" class="submitlogin">
                                                <?php esc_html_e('ثبت‌نام', 'flyairtour-theme'); ?>
                                            </button>
                                        </div>
                                        
                                        <?php wp_nonce_field('ajax-register-nonce', 'security'); ?>
                                    </form>
                                    
                                    <a class="open_sign_in"><?php esc_html_e('قبلاً ثبت‌نام کرده‌ام', 'flyairtour-theme'); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- UTILITY NAV For Application MESSAGES -->
    <div class="container-fluid utility-nav clearfix">
        <?php 
        // نمایش پیام‌های سیستم
        if (isset($_SESSION['messages'])) {
            foreach ($_SESSION['messages'] as $message) {
                echo '<div class="alert alert-' . esc_attr($message['type']) . '">';
                echo esc_html($message['text']);
                echo '</div>';
            }
            unset($_SESSION['messages']);
        }
        ?>
    </div>

<?php
/**
 * Custom Navigation Walker Class
 */
class Flyairtour_Nav_Walker extends Walker_Nav_Menu {
    
    function start_lvl(&$output, $depth = 0, $args = array()) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"dropdown-menu\">\n";
    }

    function end_lvl(&$output, $depth = 0, $args = array()) {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $id = apply_filters('nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';
        
        $output .= $indent . '<li' . $id . $class_names .'>';
        
        $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
        $attributes .= ! empty($item->target) ? ' target="' . esc_attr($item->target) .'"' : '';
        $attributes .= ! empty($item->xfn) ? ' rel="'    . esc_attr($item->xfn) .'"' : '';
        $attributes .= ! empty($item->url) ? ' href="'   . esc_attr($item->url) .'"' : '';
        
        $item_output = $args->before;
        $item_output .= '<a'. $attributes .'>';
        $item_output .= '<span class="sprte cmnexplor"></span>';
        $item_output .= '<strong>' . $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after . '</strong>';
        $item_output .= '</a>';
        $item_output .= $args->after;
        
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}
?>