<?php
/**
 * footer.php - فوتر تم فلای ایر تور
 * مشابه فوتر Travelomatix
 */
?>

    <!-- Footer Start -->
    <footer>
        <div class="fstfooter">
            <div class="container">
                <div class="row">
                    <!-- Footer Widget 1 -->
                    <div class="col-md-3 col-sm-6">
                        <?php if (is_active_sidebar('footer-1')) : ?>
                            <?php dynamic_sidebar('footer-1'); ?>
                        <?php else : ?>
                            <div class="footer-widget">
                                <h4 class="ftrhd"><?php esc_html_e('درباره فلای ایر تور', 'flyairtour-theme'); ?></h4>
                                <div class="footrlogo">
                                    <?php
                                    $custom_logo_id = get_theme_mod('custom_logo');
                                    if ($custom_logo_id) {
                                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                                        echo '<img src="' . esc_url($logo[0]) . '" alt="' . esc_attr(get_bloginfo('name')) . '">';
                                    } else {
                                        echo '<img src="' . get_template_directory_uri() . '/images/logo-footer.png" alt="' . esc_attr(get_bloginfo('name')) . '">';
                                    }
                                    ?>
                                </div>
                                <div class="foot_address">
                                    <?php 
                                    $footer_description = get_theme_mod('footer_description', 'فلای ایر تور بهترین و مطمئن‌ترین راه برای رزرو پرواز، هتل و تور است. با بیش از 10 سال تجربه در خدمات مسافرتی، ما همواره در کنار شما هستیم.');
                                    echo esc_html($footer_description);
                                    ?>
                                </div>
                                
                                <!-- Social Media Links -->
                                <ul class="signupfm">
                                    <?php
                                    $social_networks = array(
                                        'facebook' => 'fab fa-facebook-f',
                                        'twitter' => 'fab fa-twitter', 
                                        'instagram' => 'fab fa-instagram',
                                        'telegram' => 'fab fa-telegram-plane',
                                        'whatsapp' => 'fab fa-whatsapp',
                                        'youtube' => 'fab fa-youtube'
                                    );
                                    
                                    foreach ($social_networks as $network => $icon) {
                                        $url = get_theme_mod('social_' . $network);
                                        if ($url) {
                                            echo '<li><a href="' . esc_url($url) . '" target="_blank" rel="noopener" class="faftrsoc"><i class="' . esc_attr($icon) . '"></i></a></li>';
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Footer Widget 2 -->
                    <div class="col-md-3 col-sm-6">
                        <?php if (is_active_sidebar('footer-2')) : ?>
                            <?php dynamic_sidebar('footer-2'); ?>
                        <?php else : ?>
                            <div class="footer-widget">
                                <h4 class="ftrhd"><?php esc_html_e('لینک‌های مفید', 'flyairtour-theme'); ?></h4>
                                <div class="frteli">
                                    <a href="<?php echo esc_url(home_url('/flights')); ?>"><?php esc_html_e('رزرو پرواز', 'flyairtour-theme'); ?></a>
                                    <a href="<?php echo esc_url(home_url('/hotels')); ?>"><?php esc_html_e('رزرو هتل', 'flyairtour-theme'); ?></a>
                                    <a href="<?php echo esc_url(home_url('/tours')); ?>"><?php esc_html_e('تورهای گردشگری', 'flyairtour-theme'); ?></a>
                                    <a href="<?php echo esc_url(home_url('/buses')); ?>"><?php esc_html_e('بلیط اتوبوس', 'flyairtour-theme'); ?></a>
                                    <a href="<?php echo esc_url(home_url('/visa')); ?>"><?php esc_html_e('اخذ ویزا', 'flyairtour-theme'); ?></a>
                                    <a href="<?php echo esc_url(home_url('/insurance')); ?>"><?php esc_html_e('بیمه مسافرتی', 'flyairtour-theme'); ?></a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Footer Widget 3 -->
                    <div class="col-md-3 col-sm-6">
                        <?php if (is_active_sidebar('footer-3')) : ?>
                            <?php dynamic_sidebar('footer-3'); ?>
                        <?php else : ?>
                            <div class="footer-widget">
                                <h4 class="ftrhd"><?php esc_html_e('مقاصد محبوب', 'flyairtour-theme'); ?></h4>
                                <div class="frteli">
                                    <?php
                                    // نمایش مقاصد محبوب
                                    $popular_destinations = get_terms(array(
                                        'taxonomy' => 'destination',
                                        'hide_empty' => false,
                                        'number' => 6,
                                        'meta_key' => 'popular',
                                        'meta_value' => '1'
                                    ));
                                    
                                    if (!empty($popular_destinations) && !is_wp_error($popular_destinations)) {
                                        foreach ($popular_destinations as $destination) {
                                            echo '<a href="' . get_term_link($destination) . '">' . esc_html($destination->name) . '</a>';
                                        }
                                    } else {
                                        // مقاصد پیش‌فرض
                                        $default_destinations = array(
                                            'استانبول' => '/destination/istanbul',
                                            'دبی' => '/destination/dubai',
                                            'آنتالیا' => '/destination/antalya',
                                            'کیش' => '/destination/kish',
                                            'مشهد' => '/destination/mashhad',
                                            'شیراز' => '/destination/shiraz'
                                        );
                                        
                                        foreach ($default_destinations as $name => $url) {
                                            echo '<a href="' . esc_url(home_url($url)) . '">' . esc_html($name) . '</a>';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Footer Widget 4 -->
                    <div class="col-md-3 col-sm-6">
                        <?php if (is_active_sidebar('footer-4')) : ?>
                            <?php dynamic_sidebar('footer-4'); ?>
                        <?php else : ?>
                            <div class="footer-widget">
                                <h4 class="ftrhd"><?php esc_html_e('اطلاعات تماس', 'flyairtour-theme'); ?></h4>
                                <div class="foot_address">
                                    <?php 
                                    $contact_phone = get_theme_mod('contact_phone', '021-88990011');
                                    $contact_email = get_theme_mod('contact_email', 'info@flyairtour.com');
                                    $contact_address = get_theme_mod('contact_address', 'تهران، خیابان ولیعصر، پلاک 123');
                                    ?>
                                    
                                    <?php if ($contact_phone) : ?>
                                    <div style="margin-bottom: 10px;">
                                        <i class="fas fa-phone" style="margin-left: 8px; color: #00a9d6;"></i>
                                        <a href="tel:<?php echo esc_attr($contact_phone); ?>" style="color: #a2b1c7;">
                                            <?php echo esc_html($contact_phone); ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($contact_email) : ?>
                                    <div style="margin-bottom: 10px;">
                                        <i class="fas fa-envelope" style="margin-left: 8px; color: #00a9d6;"></i>
                                        <a href="mailto:<?php echo esc_attr($contact_email); ?>" style="color: #a2b1c7;">
                                            <?php echo esc_html($contact_email); ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($contact_address) : ?>
                                    <div style="margin-bottom: 15px;">
                                        <i class="fas fa-map-marker-alt" style="margin-left: 8px; color: #00a9d6;"></i>
                                        <span style="color: #a2b1c7;">
                                            <?php echo esc_html($contact_address); ?>
                                        </span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <!-- Working Hours -->
                                    <div class="working-hours" style="border-top: 1px solid #3e4154; padding-top: 15px;">
                                        <h5 style="color: #fff; margin-bottom: 10px;">
                                            <i class="fas fa-clock" style="margin-left: 8px; color: #00a9d6;"></i>
                                            <?php esc_html_e('ساعات کاری', 'flyairtour-theme'); ?>
                                        </h5>
                                        <p style="color: #a2b1c7; font-size: 13px; margin-bottom: 5px;">
                                            <?php esc_html_e('شنبه تا چهارشنبه: 8:00 - 20:00', 'flyairtour-theme'); ?>
                                        </p>
                                        <p style="color: #a2b1c7; font-size: 13px; margin-bottom: 0;">
                                            <?php esc_html_e('پنج‌شنبه: 8:00 - 14:00', 'flyairtour-theme'); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Newsletter Subscription -->
                <div class="row" style="margin-top: 30px; padding-top: 30px; border-top: 1px solid #3e4154;">
                    <div class="col-md-8">
                        <div class="newsletter-section">
                            <h4 style="color: #fff; margin-bottom: 15px;">
                                <i class="fas fa-envelope-open" style="margin-left: 8px; color: #ff9800;"></i>
                                <?php esc_html_e('عضویت در خبرنامه', 'flyairtour-theme'); ?>
                            </h4>
                            <p style="color: #a2b1c7; margin-bottom: 20px;">
                                <?php esc_html_e('از آخرین تخفیف‌ها و پیشنهادات ویژه با خبر شوید', 'flyairtour-theme'); ?>
                            </p>
                            <form id="newsletter-form" class="newsletter-form">
                                <div style="display: flex; max-width: 400px;">
                                    <input type="email" 
                                           name="newsletter_email" 
                                           placeholder="<?php esc_attr_e('آدرس ایمیل شما', 'flyairtour-theme'); ?>"
                                           required
                                           style="flex: 1; padding: 10px 15px; border: 1px solid #3e4154; background: #2c3e50; color: #fff; border-radius: 5px 0 0 5px;">
                                    <button type="submit" 
                                            style="background: #ff9800; color: #fff; border: none; padding: 10px 20px; border-radius: 0 5px 5px 0; cursor: pointer;">
                                        <i class="fas fa-paper-plane"></i>
                                        <?php esc_html_e('عضویت', 'flyairtour-theme'); ?>
                                    </button>
                                </div>
                                <?php wp_nonce_field('newsletter_nonce', 'newsletter_nonce'); ?>
                            </form>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="footer-awards" style="text-align: center;">
                            <h5 style="color: #fff; margin-bottom: 15px;">
                                <?php esc_html_e('اعتماد شما، افتخار ماست', 'flyairtour-theme'); ?>
                            </h5>
                            <div class="trust-badges" style="display: flex; justify-content: center; gap: 15px; align-items: center;">
                                <div class="trust-item" style="text-align: center;">
                                    <i class="fas fa-shield-alt" style="font-size: 2rem; color: #ff9800; margin-bottom: 5px;"></i>
                                    <div style="color: #a2b1c7; font-size: 11px;"><?php esc_html_e('پرداخت امن', 'flyairtour-theme'); ?></div>
                                </div>
                                <div class="trust-item" style="text-align: center;">
                                    <i class="fas fa-award" style="font-size: 2rem; color: #ff9800; margin-bottom: 5px;"></i>
                                    <div style="color: #a2b1c7; font-size: 11px;"><?php esc_html_e('مجوز رسمی', 'flyairtour-theme'); ?></div>
                                </div>
                                <div class="trust-item" style="text-align: center;">
                                    <i class="fas fa-users" style="font-size: 2rem; color: #ff9800; margin-bottom: 5px;"></i>
                                    <div style="color: #a2b1c7; font-size: 11px;"><?php esc_html_e('+100K مشتری', 'flyairtour-theme'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Back to Top Button -->
        <div class="footer-top__back-to-top">
            <a href="#" class="footer-top__back-to-top-link" id="back-to-top">
                <?php esc_html_e('بازگشت به بالا', 'flyairtour-theme'); ?>
            </a>
        </div>

        <!-- Copyright Section -->
        <div class="copyrit">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <p style="margin: 0;">
                            <?php
                            $current_year = date('Y');
                            $copyright_text = get_theme_mod('copyright_text', 
                                sprintf(
                                    __('© %s %s. تمامی حقوق محفوظ است.', 'flyairtour-theme'),
                                    $current_year,
                                    get_bloginfo('name')
                                )
                            );
                            echo esc_html($copyright_text);
                            ?>
                            |
                            <a href="<?php echo get_privacy_policy_url(); ?>"><?php esc_html_e('حریم خصوصی', 'flyairtour-theme'); ?></a>
                            |
                            <a href="<?php echo esc_url(home_url('/terms')); ?>"><?php esc_html_e('قوانین و مقررات', 'flyairtour-theme'); ?></a>
                        </p>
                    </div>
                    <div class="col-md-4" style="text-align: left;">
                        <p style="margin: 0; color: #a3adbc;">
                            <?php esc_html_e('طراحی و توسعه: ', 'flyairtour-theme'); ?>
                            <a href="https://flyairtour.com" style="color: #ff9800;">
                                <?php esc_html_e('تیم فنی فلای ایر تور', 'flyairtour-theme'); ?>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

<!-- JavaScript for Footer Functionality -->
<script>
jQuery(document).ready(function($) {
    // Newsletter subscription
    $('#newsletter-form').on('submit', function(e) {
        e.preventDefault();
        
        var email = $('input[name="newsletter_email"]').val();
        var nonce = $('input[name="newsletter_nonce"]').val();
        
        if (!email) {
            alert('لطفاً آدرس ایمیل خود را وارد کنید');
            return;
        }
        
        $.ajax({
            url: flyairtour_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'newsletter_subscription',
                email: email,
                nonce: nonce
            },
            beforeSend: function() {
                $('#newsletter-form button').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> در حال ارسال...');
            },
            success: function(response) {
                if (response.success) {
                    alert('با تشکر! شما با موفقیت در خبرنامه ما عضو شدید.');
                    $('#newsletter-form')[0].reset();
                } else {
                    alert(response.data || 'خطا در عضویت. لطفاً دوباره تلاش کنید.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
            },
            complete: function() {
                $('#newsletter-form button').prop('disabled', false).html('<i class="fas fa-paper-plane"></i> عضویت');
            }
        });
    });

    // Back to top button
    $('#back-to-top').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 800);
    });

    // Show/hide back to top button
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            $('.footer-top__back-to-top').fadeIn();
        } else {
            $('.footer-top__back-to-top').fadeOut();
        }
    });

    // Mobile menu toggle
    $('.menu_brgr').on('click', function() {
        $('.exploreall').slideToggle();
        $(this).toggleClass('active');
    });

    // Login/Register form switching
    $('.open_register').on('click', function(e) {
        e.preventDefault();
        $('.for_sign_in').hide();
        $('.for_sign_up').show();
    });

    $('.open_sign_in').on('click', function(e) {
        e.preventDefault();
        $('.for_sign_up').hide();
        $('.for_sign_in').show();
    });

    // Ajax Login
    $('#login_form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var username = form.find('#user_login').val();
        var password = form.find('#user_pass').val();
        var nonce = form.find('input[name="security"]').val();
        
        $.ajax({
            url: flyairtour_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'ajax_login',
                username: username,
                password: password,
                security: nonce
            },
            beforeSend: function() {
                form.find('button').prop('disabled', true).text('در حال ورود...');
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data || 'خطا در ورود. لطفاً اطلاعات خود را بررسی کنید.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            },
            complete: function() {
                form.find('button').prop('disabled', false).text('ورود');
            }
        });
    });

    // Ajax Register
    $('#register_form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = {
            action: 'ajax_register',
            display_name: form.find('input[name="display_name"]').val(),
            user_email: form.find('input[name="user_email"]').val(),
            phone: form.find('input[name="phone"]').val(),
            user_pass: form.find('input[name="user_pass"]').val(),
            confirm_password: form.find('input[name="confirm_password"]').val(),
            security: form.find('input[name="security"]').val()
        };
        
        // Validate passwords match
        if (formData.user_pass !== formData.confirm_password) {
            alert('رمزهای عبور یکسان نیستند');
            return;
        }
        
        $.ajax({
            url: flyairtour_ajax.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: formData,
            beforeSend: function() {
                form.find('button').prop('disabled', true).text('در حال ثبت‌نام...');
            },
            success: function(response) {
                if (response.success) {
                    alert('ثبت‌نام با موفقیت انجام شد. لطفاً ایمیل خود را چک کنید.');
                    form[0].reset();
                    $('.open_sign_in').click();
                } else {
                    alert(response.data || 'خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            },
            complete: function() {
                form.find('button').prop('disabled', false).text('ثبت‌نام');
            }
        });
    });

    // Currency selector
    $('.currency_li a').on('click', function(e) {
        e.preventDefault();
        
        var currency = $(this).data('currency');
        var currencyName = $(this).find('.name_currency').text();
        
        // Update display
        $('.flags').text(currencyName);
        $('.currency_li').removeClass('active');
        $(this).closest('li').addClass('active');
        
        // Store in localStorage or cookie
        if (typeof(Storage) !== "undefined") {
            localStorage.setItem('preferred_currency', currency);
        }
        
        // You can add AJAX call here to update session currency
        $.ajax({
            url: flyairtour_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'set_currency',
                currency: currency,
                nonce: flyairtour_ajax.nonce
            }
        });
    });

    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();
    
    // Initialize popovers
    $('[data-toggle="popover"]').popover();
    
    // Smooth scroll for anchor links
    $('a[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top - 80
                }, 1000);
                return false;
            }
        }
    });
});

// Load more functionality for blog/listings
function loadMorePosts(page, postType) {
    jQuery.ajax({
        url: flyairtour_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'load_more_posts',
            page: page,
            post_type: postType,
            nonce: flyairtour_ajax.nonce
        },
        beforeSend: function() {
            jQuery('.load-more-btn').text('در حال بارگذاری...');
        },
        success: function(response) {
            if (response.success) {
                jQuery('#posts-container').append(response.data.html);
                if (!response.data.has_more) {
                    jQuery('.load-more-btn').hide();
                } else {
                    jQuery('.load-more-btn').text('نمایش بیشتر').attr('data-page', page + 1);
                }
            }
        }
    });
}

// Search autocomplete for cities
function initCityAutocomplete() {
    jQuery('.city-autocomplete').autocomplete({
        source: function(request, response) {
            jQuery.ajax({
                url: flyairtour_ajax.ajax_url,
                dataType: 'json',
                data: {
                    action: 'city_search',
                    term: request.term,
                    nonce: flyairtour_ajax.nonce
                },
                success: function(data) {
                    response(data.data || []);
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            jQuery(this).val(ui.item.label);
            return false;
        }
    });
}

// Initialize on document ready
jQuery(document).ready(function() {
    initCityAutocomplete();
});
</script>

<?php wp_footer(); ?>

</body>
</html>