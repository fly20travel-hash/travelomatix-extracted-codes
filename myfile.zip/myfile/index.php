<?php
/**
 * index.php - صفحه اصلی تم فلای ایر تور
 * مشابه صفحه اصلی Travelomatix
 */

get_header(); ?>

<div class="allpagewrp">
    <!-- منطقه جستجو و hero section -->
    <div class="searcharea">
        <div class="srchinarea">
            <div class="container">
                <div class="captngrp">
                    <div id="big1" class="bigcaption">
                        <?php 
                        $hero_title = get_theme_mod('hero_title', 'سفری فراموش‌نشدنی را تجربه کنید');
                        echo esc_html($hero_title);
                        ?>
                    </div>
                    <div id="desc" class="smalcaptn">
                        <?php 
                        $hero_subtitle = get_theme_mod('hero_subtitle', 'بهترین قیمت‌ها برای پرواز، هتل و تور');
                        echo esc_html($hero_subtitle);
                        ?>
                        <span class="boder"></span>
                    </div>
                </div>
            </div>

            <!-- فرم جستجو -->
            <div class="allformst">
                <div class="container inspad">
                    <div class="secndblak">
                        <div class="tab-content custmtab">
                            
                            <!-- تب پرواز -->
                            <div class="tab-pane active" id="flight">
                                <!-- منوی تب‌ها -->
                                <ul class="nav nav-tabs customtab" role="tablist">
                                    <li class="active">
                                        <a href="#flight" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-plane morefa"></i> پرواز</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#hotel" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-building morefa"></i> هتل</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#tour" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-route morefa"></i> تور</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#bus" role="tab" data-toggle="tab">
                                            <span><i class="fas fa-bus morefa"></i> اتوبوس</span>
                                        </a>
                                    </li>
                                </ul>

                                <!-- فرم جستجوی پرواز -->
                                <form autocomplete="off" name="flight" id="flight_form" action="<?php echo esc_url(home_url('/flight-search')); ?>" method="get" class="activeForm oneway_frm">
                                    <div class="tabspl">
                                        <div class="tabrow">
                                            <!-- نوع سفر -->
                                            <div class="waywy">
                                                <div class="smalway">
                                                    <label class="wament hand-cursor active">
                                                        <input class="hide" type="radio" name="trip_type" checked="checked" id="onew-trp" value="oneway" /> 
                                                        یک طرفه
                                                    </label>
                                                    <label class="wament hand-cursor">
                                                        <input class="hide" type="radio" name="trip_type" id="rnd-trp" value="circle" /> 
                                                        رفت و برگشت
                                                    </label>
                                                    <label class="wament hand-cursor">
                                                        <input class="hide" type="radio" name="trip_type" id="multi-trp" value="multicity" /> 
                                                        چند شهره
                                                    </label>
                                                </div>
                                            </div>

                                            <!-- فیلدهای مبدا و مقصد -->
                                            <div id="onw_rndw_fieldset" class="col-md-8 nopad">
                                                <div class="col-md-7 nopad placerows">
                                                    <div class="col-xs-6 padfive">
                                                        <div class="lablform">مبدا</div>
                                                        <div class="plcetogo deprtures sidebord">
                                                            <input type="text" autocomplete="off" name="from" class="normalinput auto-focus valid_class fromflight form-control b-r-0" id="from" placeholder="شهر مبدا" value="" required />
                                                            <input class="hide loc_id_holder" id="from_loc_id" name="from_loc_id" type="hidden" value="" >
                                                            <div class="flight_chnge">
                                                                <i class="fas fa-exchange-alt rot_arrow"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6 padfive">
                                                        <div class="lablform">مقصد</div>
                                                        <div class="plcetogo destinatios sidebord">
                                                            <input type="text" autocomplete="off" name="to" class="normalinput auto-focus valid_class departflight form-control b-r-0" id="to" placeholder="شهر مقصد" value="" required/>
                                                            <input class="hide loc