<?php
/**
 * functions.php - فایل توابع تم فلای ایر تور
 * مشابه سیستم Travelomatix با قابلیت‌های کامل
 */

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// ثوابت تم
define('FLYAIRTOUR_VERSION', '1.0.0');
define('FLYAIRTOUR_THEME_DIR', get_template_directory());
define('FLYAIRTOUR_THEME_URI', get_template_directory_uri());

/**
 * تنظیمات اولیه تم
 */
function flyairtour_setup() {
    // پشتیبانی از زبان‌های مختلف
    load_theme_textdomain('flyairtour-theme', get_template_directory() . '/languages');

    // پشتیبانی از تصویر شاخص پست
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(300, 200, true);

    // اندازه‌های مختلف تصاویر
    add_image_size('flyairtour-large', 800, 600, true);
    add_image_size('flyairtour-medium', 400, 300, true);
    add_image_size('flyairtour-small', 200, 150, true);
    add_image_size('flyairtour-deal', 350, 250, true);

    // پشتیبانی از RSS
    add_theme_support('automatic-feed-links');

    // پشتیبانی از عنوان صفحه
    add_theme_support('title-tag');

    // پشتیبانی از HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // پشتیبانی از لوگو سفارشی
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // ثبت منوها
    register_nav_menus(array(
        'primary' => esc_html__('منوی اصلی', 'flyairtour-theme'),
        'footer'  => esc_html__('منوی فوتر', 'flyairtour-theme